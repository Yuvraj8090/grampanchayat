<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       <title> vijaypur gopiwala Gram Panchayat Welcome you</title>
        <link href="style.css" rel="stylesheet" type="text/css" />
        <!-- Start cssSlider.com -->
	<link rel="stylesheet" href="engine1/style.css">

	<!--[if IE]><link rel="stylesheet" href="engine1/ie.css"><![endif]-->
	<!--[if lte IE 9]><script type="text/javascript" src="engine1/ie.js"></script><![endif]-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		
        <META NAME="Author" CONTENT="Universal Web Solutions">
        <META NAME="Subject" CONTENT="Bhagvantpur Gram Panchayat, Uttarakhand">
        <META NAME="Description" CONTENT="Welcome to Bhagvantpur gram panchayat. it is a first website of Bhagvantpur gram panchayat. it is made by gram pradhan.  ">
        <META NAME="Keywords" CONTENT="Bhagvantpur Gram Panchayat,Bhagvantpur gram panchayat,Bhagvantpur gram panchayat dehradun ,Bhagvantpur gram panchayat vikasnagar ,uttarakhand gram panchayat,gram panchyat  provide best facility for accomdation">
        <META NAME="Generator" CONTENT="Universal Web Solutions">
        <META NAME="Language" CONTENT="English">
	
<?php include '../googleads.php' ?> 


    </head>
    <body>
       
    <div id="maincontainer"><!-- main container close -->
	<?php include '../headerlink.php';  ?>
         <div id="leftarea">
	   
	   <!-- /42186683/left_Ad120*600 -->

			<div id='div-gpt-ad-1429857924193-0' style='height:600px; width:120px;'>
			<script type='text/javascript'>
			googletag.cmd.push(function() { googletag.display('div-gpt-ad-1429857924193-0'); });
			</script>
			</div>
		</div>
		<div id="rightarea">
		  <!-- /42186683/Right_ads120*600 -->
			<div id='div-gpt-ad-1429857924193-1' style='height:600px; width:120px;'>
			<script type='text/javascript'>
			googletag.cmd.push(function() { googletag.display('div-gpt-ad-1429857924193-1'); });
			</script>
			</div>
		</div>
		
      <div id="headerconatiner">
          <div id="headerconatinerleft">
              <h3><a href="index.php"> गोपीवाला ग्राम पंचायत</a> 
<span style="font-size:14px;"><br/> निर्माणवर्ष 20 मई २०१७  &nbsp; &nbsp; &nbsp; &nbsp; वर्तमान नलिन प्रधान</span></h3>
            
          </div>
          <div id="headerconatinerright">vijaypurgopiwala@grampanchayat.org || <a align="right" href="http://www.grampanchayat.org/webmail" target="_blank" >webmail</a></p>
              <p> <img src="../social/phone.png" />&nbsp+91-9557304871</p>
			  <?php $url=$_SERVER['HTTP_HOST'] .$_SERVER['REQUEST_URI'];?>
              						<p> <a href="http://www.facebook.com/share.php?u=<?php echo $url; ?>" target="_blank" title=share on facebook"><img src="../social/facebook.png" alt="Babhangama share on facebook"/></a> &nbsp; <a href="#" title="share on facebook"><img src="../social/twitter.png" alt="share on Twitter"/></a> &nbsp; <a href="https://www.youtube.com/channel/UColQLlZEDMmz09_17fNZOjg/videos" target="_blank" title="share on You Tube"><img src="../social/youtube.png" alt="Babhangama on Youtube"/></a> &nbsp; <a href="#" title="share on facebook"><img src="../social/google.png" alt="share on google+"/></a></p>

              
          </div>
          <div class="cl"></div>  
      </div> <!-- header container close -->
      <div id="menu"> 
          <a href="index.php"> <span  id="menutext">  होम </span></a> |
          <!-- <a href="#"> <span  id="menutext">  ग्राम पंचायत</span> </a>| -->
          <a href="pradhan-message.php"> <span  id="menutext">  प्रधान सन्देश </span></a>|
           <a href="tourist-place.php"><span  id="menutext"> मुख्य स्थल  </span></a>|
          <a href="gallery.php"> <span  id="menutext"> गैलरी</span> </a>|
          <a href="videos.php"> <span  id="menutext"> विडियो </span> </a>|
          <a href="panchyat-business.php"> <span  id="menutext"> ग्राम्य व्यवसाय </span></a> |
          <a href="gram-panchayat-leaders.php"> <span  id="menutext"> पंचायत  प्रतिनिधि</span></a> |
          <a href="#"> <span  id="menutext"> वीर महिला@पुरुष   </span> </a> |
          <a href="contact-us.php"> <span  id="menutext"> संपर्क </span> </a>
      </div>