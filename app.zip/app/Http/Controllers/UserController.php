<?php

namespace App\Http\Controllers\APIS;

use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(){
        return "sdfssaf";
    }
}