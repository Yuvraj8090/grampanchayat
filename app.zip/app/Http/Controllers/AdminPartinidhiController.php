<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ImportantPosts;

class AdminPartinidhiController extends Controller
{

     public function index(Request $request,$id)
    {   
        
        $data = ImportantPosts::where('ref_id',$id)->orderBy('id','DESC')->paginate('20');
        
        $add = "";
        if($request->idd){
             $add = ImportantPosts::where('id',$request->idd)->first(); 
        }
        
        return view('admin.partinidhi.index',compact('data','add','id'));
    }
    
    
    public function store(Request $request){
        
        $this->validate($request,[
            'content' => 'required',
            'link' => 'required|url'
        ]);
        
        $data = $request->only(['content','ref_id','link']);
        
        $res = ImportantPosts::create($data);
        
        if($res){
               return back()->with('insert','New Title Added Successfully.');
        }
        
        return back()->with('insert','Error! Please try Again after sometime.');
        
    }
    
    public function edit(){
        
    }
    
    public function update(Request $request,$id){
            
        $this->validate($request,[
            'content' => 'required',
            'link' => 'required'
        ]);
    
        $data = $request->only(['content','link']);
        
        $res = ImportantPosts::find($id)->update($data);
        
        if($res){
               return redirect()->to('points/index/'.$request->ref_id)->with('insert','Title updated Successfully.');
        }
        
        return back()->with('insert','Error! Please try Again after sometime.');
        
    }
    
    public function delete($id){
        
        $res = ImportantPosts::find($id)->delete();
        
        if($res){
               return back()->with('insert','Title deleted Successfully.');
        }
        
        return back()->with('insert','Error! Please try Again after sometime.');
    }
    
    
}
