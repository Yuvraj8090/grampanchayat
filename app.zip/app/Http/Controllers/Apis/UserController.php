<?php

namespace App\Http\Controllers\Apis;

use App\{User,Media,Fact,ListName,Pmsg,Work,Address,Register,Business,Video,Intro,Place,States,Districts,Blocks,ImporantTitle,Feedback};

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    public function index($slug){
        
        $user = User::select('name','email','id')->whereSlug($slug)->firstOrFail();

        // $data = cache()->remember('home6', 1, function () use ($user) {
                
            $photo = Media::where('user_id', '=', $user->id)->get();
            $photo = $this->mediaPath($photo,['image']);
            
            $intro = Intro::where('user_id', '=', $user->id)->first();
            $intro = $this->removeHtml($intro,['intro'],FALSE);
    
            $fact = Fact::where('user_id', '=', $user->id)->get();
            
    
            $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
            $name = $this->mediaPath($name ,['image'],FALSE);
            
            $data = [
                        'user' => $user,
                        'photo' => $photo,
                        'intro' => $intro,
                        'fact' => $fact,
                        'listName' => $name
                ];
            // });
        
            return response()->json([
                'statue' => 'true',
                'data' => $data,
                'message' => 'Success'
            ],200);
        
    }
    
    public function message($slug){
        
        $user = User::whereSlug($slug)->firstOrFail();
    
        // $data = cache()->remember('message2', 1000, function () use ($user) {
            
                $msg = Pmsg::where('user_id', '=', $user->id)->first();
                $msg = $this->removeHtml($msg,['msg'],FALSE);
                $msg = $this->mediaPath($msg,['image'],FALSE);
                
                $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
                $name = $this->mediaPath($name,['image'],FALSE);
                
                $data =  [
                    
                    'msg' => $msg,
                    'name' => $name
                ];

        // });
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
       
    }
    
    public function place($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();

        // $data = cache()->remember('place1', 1000, function () use ($user) {
            
            $intro = Place::where('user_id', '=', $user->id)->where('intro', '!=', null)->first();
            $intro = $this->removeHtml($intro,['intro'],FALSE);
            $intro = $this->mediaPath($intro,['image'],FALSE);

            $place = Place::where('user_id', '=', $user->id)->where('intro', '=', null)->paginate('6');
            $place = $this->mediaPath($place,['image']);
            
            $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
            $name = $this->mediaPath($name,['image'],FALSE);
        
            $data =  [
                    'intro' => $intro,
                    'place' => $place,
                    'name' => $name
            ];
        //     return $data;
        // });

        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
    }
    
    public function gallery($slug){
         
        $user = User::whereSlug($slug)->firstOrFail();
        
        // $data = cache()->remember('gallery2', 1000, function () use ($user) {
            
                $photo = Media::where('user_id', '=', $user->id)->where('gallery', '=', 1)->paginate('6');
                $photo = $this->mediaPath($photo,['image']);

                $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
                 $name = $this->mediaPath($name,['image'],FALSE);
                
                $data = [
                    'photo' => $photo,
                    'name' => $name
                ];
        // });
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
        
    }
    
    public function video($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();

        // $data = cache()->remember('video', 1000, function () use ($user) {
            
            $video = video::where('user_id', '=', $user->id)->get();
            
            foreach($video as $v){
                $v['url'] = 'https://www.youtube.com/watch?v='.$v->url;
            }
            $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
                
            $data =  [
                    'video' => $video,
                    'name' => $name
            ];
        // });

        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);

    }

    public function business($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();
        
        // $data = cache()->remember('business1', 1000, function () use ($user) {
            
            $intro = Business::where('user_id', '=', $user->id)->where('intro', '!=', null)->first();
            $intro = $this->removeHtml($intro,['intro'],FALSE);
            $intro = $this->mediaPath($intro,['image'],FALSE);

            $business = Business::where('user_id', '=', $user->id)->where('intro', '=', null)->paginate('6');
            $business = $this->removeHtml($business,['about'],TRUE);
            $business = $this->mediaPath($business,['image'],TRUE);

            $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
            $name = $this->mediaPath($name,['image'],FALSE);
                
            $data =   [
                    'intro' => $intro,
                    'business' => $business,
                    'name' => $name
            ];
            
        // });

        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);

    }

    public function lead($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();
        
        // $data = cache()->remember('lead1', 1000, function () use ($user) {
            
            $list = ListName::where('user_id', '=', $user->id)->get();
            $list = $this->mediaPath($list,['image'],TRUE);
            
            $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
            $name = $this->mediaPath($name,['image'],FALSE);
            
            $data =  [
                    'list' => $list,
                    'name' => $name
            ];
        // });

        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);

    }
    
    public function contact($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();
        
        // $data = cache()->remember('contact1', 1000, function () use ($user) {
            
             $add = Address::where('user_id', '=', $user->id)->where('address', '!=', null)->first();
             $lo = Address::where('user_id', '=', $user->id)->where('address', '=', null)->get();
             $name = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
             $name = $this->mediaPath($name,['image'],FALSE);
                 
            $data = [
                        'add' => $add,
                        'lo' => $lo,
                        'name' => $name
            ];
        // });

        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);

    }
    
    public function getAllUserNames(Request $request){
        
        $data =  User::query();
        
        $data->select('id','role_id','name','hindi as hindi_name','state_id','district_id','block_id');
        $data->where('role_id','2');
        if($request->state_id){
            $data->where('state_id',$request->state_id);
        }
        
        if($request->district_id){
            $data->where('state_id',$request->district_id);
        }
        
        if($request->block_id){
            $data->where('block_id',$request->block_id);
        }
        
        $data = $data->get();
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
    }
    
    public function getAllStates(){
        
        $data =  States::where('status','1')->get();
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
    }
    
     public function getStateDistrict($id){
        
        $data =  Districts::where('state_id',$id)->where('status','1')->get();
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
        
        
    }
    
     public function getDistictBlock($id){
        
        $data =  Blocks::where('district_id',$id)->where('status','1')->get();
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
    }
    
    
    public function work($slug)
    {
        $user = User::whereSlug($slug)->firstOrFail();

        $data['work'] = Work::where('user_id', '=', $user->id)->get();

        $data['name'] = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
        
        
         return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);

    }
    
      public function importantInformation($slug){
        
        $user = User::whereSlug($slug)->firstOrFail();
        $data['name'] = ListName::where('user_id', '=', $user->id)->where('position', '=', 'प्रधान')->first();
        
        $data['data'] = ImporantTitle::with('posts')->orderBy('id','desc')->get();
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
        
        return response()->json([
            'statue' => 'true',
            'data' => $data,
            'message' => 'Success'
        ],200);
        
    }
    
    
    public function feeback(Request $request){
        
        $validator = Validator::make($request->all(),[
            'name' => 'required|max:30',
            'email' => 'required|email',
            'phone' => 'required|digits:10',
            'message' => 'required|max:400'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()],422);
        }
        
        $data = $request->only(['name','email','phone','message']);
        
        $data = Feedback::create($data);
        
        if($data){
            return response()->json([
                'statue' => 'true',
                'message' => 'Success! Message sent successfully.'
            ],200);
        }
        
        return response()->json([
            'statue' => 'false',
            'message' => 'Error! Please try gain after sometime.'
        ],500);
        
    }

    
}