@extends('layouts.admin')

@section('content')
<style>
    .card{
        margin:10px;
        border:1px solid black;
        padding:10px 10px;
    }
</style>
<br/>
@if(Session::has('insert'))
    <div class="alert alert-success">
        <strong> {{session('insert')}}</strong>
    </div><br/>
@endif

@if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif


    <div class="card">
          <div class="card-header">
            <h4>Add Title </h4>
          </div>
          <div class="card-body">
                
                @if(isset($add->title))
                    {!! Form::open(['method' => 'PATCH', 'action' => ['AdminImportantController@update', $add->id]]) !!}
                @else
                    {!! Form::open(['method'=>'POST', 'action'=>'AdminImportantController@store']) !!}
                @endif

                <input type="textbox" class="form-control" name="title"  value="{{ $add->title ?? request()->title ?? '' }}"  />
               <br>
                <button type="submit" class="btn btn-sm btn-primary">Submit</button>
            </form>
          </div>
    </div> <br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:40px;">S.No</th>
                            <th class="text-center" style="width:120px;">Point</th>
                            <th class="text-center" style="width:100px;">Created Date</th>
                            <th class="text-center" style="width:120px;">Operation</th>
                        </thead>
                        
                        <tbody>
                            @if(count($data) > 0)
                                @foreach($data as $key => $d)
                                    <tr>
                                        <td>{{ $data->firstItem() + $key }}</td>
                                        <td>{{ $d->title }} </td>
                                        <td>{{ date("d,M Y h:i A",strtotime($d->created_at)) }} </td>
                                         <td>
                                            <a class="btn btn-info btn-sm" href="{{ route('important.index') }}?id={{$d->id}}">Edit</a>
                                            <a class="btn btn-danger btn-sm" onClick-"return confirm('Are you sure ?')" href="{{ url('important/delete/'.$d->id) }}">Delete</a> 
                                            <a class="btn btn-primary btn-sm" href="{{ url('points/index/'.$d->id) }}">Add Points</a> 
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
@endsection