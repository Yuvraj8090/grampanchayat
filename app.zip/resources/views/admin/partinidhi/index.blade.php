@extends('layouts.admin')

@section('content')
<style>
    .card{
        margin:10px;
        border:1px solid black;
        padding:10px 10px;
    }
</style>
<br/>
@if(Session::has('insert'))
    <div class="alert alert-success">
        <strong> {{session('insert')}}</strong>
    </div><br/>
@endif

@if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif


    <div class="card">
          <div class="card-header">
            <h4>Add Title </h4>
          </div>
          <div class="card-body">
                
                @if(isset($add->id))
                    {!! Form::open(['method' => 'PATCH', 'action' => ['AdminPartinidhiController@update', $add->id]]) !!}
                @else
                    {!! Form::open(['method'=>'POST', 'action'=>'AdminPartinidhiController@store']) !!}
                @endif
                
                <input type="hidden" name="ref_id" value="{{ $id ?? '' }}" />
                <input type="textbox" class="form-control" name="content" placeholder="Point title..."  value="{{ $add->content ?? request()->content ?? '' }}"  />
               <br>
                <input type="url" class="form-control" name="link"  placeholder="Link Url..." value="{{ $add->link ?? request()->link ?? '' }}"  />
               <br>
                <button type="submit" class="btn btn-sm btn-primary">Submit</button>
            </form>
          </div>
    </div> <br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:40px;">S.No</th>
                            <th class="text-center" style="width:120px;">Point</th>
                            <th class="text-center" style="width:120px;">Link</th>
                            <th class="text-center" style="width:100px;">Created Date</th>
                            <th class="text-center" style="width:120px;">Operation</th>
                        </thead>
                        
                        <tbody>
                            @if(count($data) > 0)
                                @foreach($data as $key => $d)
                                    <tr>
                                        <td>{{ $data->firstItem() + $key }}</td>
                                        <td>{{ $d->content }} </td>
                                        <td>{{ $d->link ?? "NULL" }} </td>
                                        <td>{{ date("d,M Y h:i A",strtotime($d->created_at)) }} </td>
                                         <td>
                                            <a class="btn btn-info btn-sm" href="{{ url('points/index/'.$id) }}?idd={{$d->id}}">Edit</a>
                                            <a class="btn btn-danger btn-sm" onClick="return confirm('Are you sure ?')" href="{{ url('points/delete/'.$d->id) }}">Delete</a> 
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
@endsection