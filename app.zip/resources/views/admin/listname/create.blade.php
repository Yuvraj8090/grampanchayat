@extends('layouts.admin')

@section('content')

<div class="container">
    <br>
    <a href="{{route('admin-user.index')}}" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>

    <br><br>
    <form action="{{ route('jan-partinidhi.store')}}" method="POST" >

    <input type="hidden" name="_token" value="{{ csrf_token() }}" />

    <div class="form-group">
            <label for="exampleInputEmail1">Select Grampanchayat : </label>
            <select class="form-control" name="user">
                <option value="">Select </option>
                @if(count($users) > 0)
                @foreach($users as $user)
                <option value="{{ $user->id }}"> {{ $user->name }}</option>
                @endforeach
                @endif
            </select>
            @if ($errors->has('user'))
            <span class="help-block">
                <strong>{{ $errors->first('user') }}</strong>
            </span>
            @endif
        </div>

        <div class="row{{ $errors->has('stream') ? ' has-error' : '' }}">
                        <div class="form-group">
                            <label class="col-md-4 control-label">State</label>
                            <div class="col-md-6">
                                <select   data-url="{{ url('/disticts') }}" data-variable="district"  class="form-control element " name="state" required="required">
                                    @if(count($states) > 0)
                                        <option value="" >Select State</option>
                                        @foreach($states as $state)
                                            <option value="{{$state->id}}" >{{$state->name}}</option>
                                            
                                        @endforeach
                                    @endif
                                </select>
                                @if ($errors->has('stream'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('stream') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <br/>
                    
                    <div class="row{{ $errors->has('stream') ? ' has-error' : '' }}">
                        <div class="form-group">
                            <label class="col-md-4 control-label">District</label>
                            <div class="col-md-6">
                                <select id="district"  data-url="{{ url('/blocks') }}"  data-variable="block"   class="form-control element" name="district" required="required">
                                  
                                        <option value="" >Select District</option>
                                      

                                </select>
                                @if ($errors->has('district'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('district') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <br/>
                    
                    <div class="row{{ $errors->has('stream') ? ' has-error' : '' }}">
                        <div class="form-group">
                            <label class="col-md-4 control-label">Block</label>
                            <div class="col-md-6">
                                <select id="block" class="form-control" name="block" required="required">
                                
                                        <option value="" >Select Block</option>
                                       
                               
                                </select>
                                @if ($errors->has('block'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('block') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <br/>
        
      
  
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>

@endsection