@extends('layouts.admin')

@section('content')

<div class="container">
    <br>
    <a href="{{route('admin-user.index')}}" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br><br>


    @if(Session::has('insert'))
    <div class="alert alert-success">
        <strong> {{session('insert')}}</strong>
    </div><br />
    @endif

    @if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif



    <form action="{{ url('jan-partinidhi/excel/upload')}}" method="POST" enctype="multipart/form-data">

        <input type="hidden" name="_token" value="{{ csrf_token() }}" />

        <div class="form-group">
            <label for="exampleInputEmail1">Select Grampanchayat : </label>
            <select class="form-control" name="user">
                <option value="">Select </option>
                @if(count($users) > 0)
                @foreach($users as $user)
                <option value="{{ $user->id }}"> {{ $user->name }}</option>
                @endforeach
                @endif
            </select>
            @if ($errors->has('user'))
            <span class="help-block">
                <strong>{{ $errors->first('user') }}</strong>
            </span>
            @endif
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1"> Excel File :</label>
            <input type="file" name="file" class="form-control" id="exampleInputPassword1" placeholder="Excel File">
            @if ($errors->has('file'))
            <span class="help-block">
                <strong>{{ $errors->first('file') }}</strong>
            </span>
            @endif
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>

@endsection