<!DOCTYPE html>
<html>
<head>
	<title>404 - Gram Panchayat</title>
</head>
<body>
	<center><img src="/images/404.png" class="img-responsive" alt="404 = Gram Panchayat"></center>
</body>
</html>