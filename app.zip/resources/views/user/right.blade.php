<div class="panel panel-default">
                        <div class="panel-heading new_p_head text-center">ताजा खबरे </div>
                        <div class="panel-body">
                            <ul class="rightul">
                                <li><a href="">सीएम योगी आदित्यनाथ का व्हाट्सएप नंबर और शिकायतों के लिए संपर्क नंबर</a></li>
                                <li><a href="">प्रधानमंत्री आवास योजना का ऑनलाइन आवेदन कैसे करें – पूर्ण विवरण</a></li>
                                <li><a href="">प्रधानमंत्री ग्रामीण आवास योजना</a></li>
                                <li><a href="">Pmaymis.gov.in पर PMAY की लाभार्थियों की सूची में अपना नाम जांचें</a></li>
                                <li><a href="">प्रधान मंत्री फसल बीमा योजना का agri-insurance.gov.in पर ऑनलाइन आवेदन करें।</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading new_p_head text-center">Running योजनाए  </div>
                        <div class="panel-body">
                            <ul class="rightul">
                                <li><a href="">सीएम योगी आदित्यनाथ का व्हाट्सएप नंबर और शिकायतों के लिए संपर्क नंबर</a></li>
                                <li><a href="">प्रधानमंत्री आवास योजना का ऑनलाइन आवेदन कैसे करें – पूर्ण विवरण</a></li>
                                <li><a href="">प्रधानमंत्री ग्रामीण आवास योजना</a></li>
                                <li><a href="">Pmaymis.gov.in पर PMAY की लाभार्थियों की सूची में अपना नाम जांचें</a></li>
                                <li><a href="">प्रधान मंत्री फसल बीमा योजना का agri-insurance.gov.in पर ऑनलाइन आवेदन करें।</a></li>
                            </ul>
                        </div>
                    </div>
                    <iframe width="100%" height="250" src="https://www.youtube.com/embed/EJ89r_Gw1Gg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br/><br/>
                    <div class="panel panel-default">
                        <div class="panel-heading new_p_head text-center">सरकारी नौकरियों  </div>
                        <div class="panel-body">
                            <ul class="rightul">
                                <li><a href="">सीएम योगी आदित्यनाथ का व्हाट्सएप नंबर और शिकायतों के लिए संपर्क नंबर</a></li>
                                <li><a href="">प्रधानमंत्री आवास योजना का ऑनलाइन आवेदन कैसे करें – पूर्ण विवरण</a></li>
                                <li><a href="">प्रधानमंत्री ग्रामीण आवास योजना</a></li>
                                <li><a href="">Pmaymis.gov.in पर PMAY की लाभार्थियों की सूची में अपना नाम जांचें</a></li>
                                <li><a href="">प्रधान मंत्री फसल बीमा योजना का agri-insurance.gov.in पर ऑनलाइन आवेदन करें।</a></li>
                            </ul>
                        </div>
                    </div>