<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>tinymce.init({ selector:'.te' });</script>
<style type="text/css">
    #mceu_31
    {
        display:none!important;
    }
</style>
<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-introduction.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::open(['method'=>'POST', 'action'=>'UserIntro@store']); ?>


        <div class="form-group<?php echo e($errors->has('introduction') ? ' has-error' : ''); ?>">
            <label>Introduction</label>
            <input type="text" name="introduction" class="form-control te" style="min-height:400px;">
            <?php if($errors->has('introduction')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('introduction')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>