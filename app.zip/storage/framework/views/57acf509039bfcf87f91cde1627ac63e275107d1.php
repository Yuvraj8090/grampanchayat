<?php $__env->startSection('content'); ?>
<style>
    .card {
        margin: 10px;
        border: 1px solid black;
        padding: 10px 10px;
    }
</style>
<br />
<?php if(Session::has('insert')): ?>
<div class="alert alert-success">
    <strong> <?php echo e(session('insert')); ?></strong>
</div><br />
<?php endif; ?>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>


<div class="table-responsive">

    <div style="padding-left:50px;" >
        <a class="btn bt-md btn-primary" href="<?php echo e(route('jan-partinidhi.create')); ?>">Add </a>
        <a class="btn bt-md btn-primary" href="<?php echo e(url('jan-partinidhi/excelUpload')); ?>">Add By Excel</a>
        <br><br>
    </div>
   

    <table class="table table-bordered table-striped">
        <thead>
            <th class="text-center" style="width:40px;">S.No</th>
            <th class="text-center" style="width:120px;">Name</th>
            <th class="text-center" style="width:120px;">Position</th>
            <th class="text-center" style="width:120px;">Block</th>
            <th class="text-center" style="width:120px;">Phone</th>
            <th class="text-center" style="width:100px;">Created Date</th>
            <th class="text-center" style="width:120px;">Operation</th>
        </thead>

        <tbody>
            <?php if(count($data) > 0): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data->firstItem() + $key); ?></td>
                <td><?php echo e($d->name); ?> </td>
                <td><?php echo e($d->position); ?> </td>
                <td><?php echo e($d->block); ?> </td>
                <td><?php echo e($d->phone); ?> </td>
                <td><?php echo e(date("d,M Y h:i A",strtotime($d->created_at))); ?> </td>
                <td>
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('jan-partinidhi.edit',$d->id)); ?>">Edit</a>
                    <a class="btn btn-danger btn-sm" onClick="return confirm('Are you sure ?')" href="<?php echo e(url('jan-partinidhi/delete/'.$d->id)); ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <div style="padding-left:50px;">
        <?php echo e($data->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>