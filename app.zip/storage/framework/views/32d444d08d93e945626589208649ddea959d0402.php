<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8" />
    <title>BCORE Admin Dashboard Template | Dashboard </title>
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <!-- GLOBAL STYLES -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/MoneAdmin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/layout2.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--END GLOBAL STYLES -->
</head>

    <!-- END HEAD -->

    <!-- BEGIN BODY -->
<body class="padTop53 " >

    <!-- MAIN WRAPPER -->
    <div id="wrap" >
        

        <!-- HEADER SECTION -->
        <div id="top">

            <nav class="navbar navbar-inverse navbar-fixed-top " style="padding-top: 10px;">
                <a data-original-title="Show/Hide Menu" data-placement="bottom" data-tooltip="tooltip" class="accordion-toggle btn btn-primary btn-sm visible-xs" data-toggle="collapse" href="#menu" id="menu-toggle">
                    <i class="icon-align-justify"></i>
                </a>
                <!-- LOGO SECTION -->
                <header class="navbar-header">

                    <a href="" class="navbar-brand">
                        Garam Panchayat
                        
                        </a>
                </header>
                <!-- END LOGO SECTION -->
                <ul class="nav navbar-top-links navbar-right">

                   

                   

                   

                    <!--ADMIN SETTINGS SECTIONS -->

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user "></i>&nbsp; <i class="fa fa-angle-down "></i>
                        </a>

                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="fa fa-user"></i> User Profile </a>
                            </li>
                            <li><a href="#"><i class="fa fa-gear"></i> Settings </a>
                            </li>
                            <li class="divider"></li>
                            <li><a href=""> Logout </a>
                            </li>
                        </ul>

                    </li>
                    <!--END ADMIN SETTINGS -->
                </ul>

            </nav>

        </div>
        <!-- END HEADER SECTION -->



        <!-- MENU SECTION -->
      <div id="left" >
            <div class="media user-media well-small">
                <div class="media-body">
                    <h5 class="media-heading" style="font-size:15px;padding:5px;"><a href="../index.php" target="_
                    blank">View Website</a></h5>
                    <ul class="list-unstyled user-info">
                        
                        <li>
                             <a class="btn btn-success btn-xs btn-circle" style="width: 10px;height: 12px;"></a> Online
                           
                        </li>
                       
                    </ul>
                </div>
                <br />
            </div>

            <ul id="menu" class="collapse">

                
                <li class="panel active">
                    <a href="dashboard.php" >
                        <i class="icon-table"></i> Dashboard
       
                       
                    </a>                   
                </li>

<li><a href="slider_images.php"><i class="icon-table"></i> Slider Images </a></li>
<li><a href="introduction.php"><i class="icon-table"></i> परिचय </a></li>
<li><a href="key_facts.php"><i class="icon-table"></i> मुख्य तथ्य </a></li>
<li><a href="pradhan_message.php"><i class="icon-table"></i> प्रधान सन्देश </a></li>
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#component-nav">
                        <i class="icon-tasks"> </i> जनप्रतिनिधि      
       
                        <span class="pull-right">
                          <i class="fa fa-angle-left"></i>
                        </span>
                       
                    </a>
                    <ul class="collapse" id="component-nav">
                       
                        <li class=""><a href="janparthinidhi.php"><i class="icon-angle-right"></i> पंचायत स्तर </a></li>
                         <li class=""><a href="icon.html"><i class="icon-angle-right"></i> ब्लॉक स्तर  </a></li>
                        <li class=""><a href="progress.html"><i class="icon-angle-right"></i> जनपद स्तर  </a></li>
                        <li class=""><a href="tabs_panels.html"><i class="icon-angle-right"></i> राज्य  स्तर  </a></li>
                    </ul>
                </li>
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-nav">
                        <i class="icon-pencil"></i> संपर्क 
       
                        <span class="pull-right">
                            <i class="fa fa-angle-left"></i>
                        </span>
                         
                    </a>
                    <ul class="collapse" id="form-nav">
                        <li class=""><a href="address.php"><i class="icon-angle-right"></i> पता  </a></li>
                        <li class=""><a href="location.php"><i class="icon-angle-right"></i> जाने का साधन </a></li>
                    </ul>
                </li>
                <li><a href="vikaskarye.php"><i class="icon-table"></i> विकास कार्य  </a></li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#DDL-nav">
                        <i class=" icon-sitemap"></i> मुख्य स्थल
       
                        <span class="pull-right">
                            <i class="fa fa-angle-left"></i>
                        </span>
                    </a>
                    <ul class="collapse" id="DDL-nav">
                        <li><a href="place_intro"><i class="icon-angle-right"></i> परिचय </a></li>
                        <li><a href="places.php"><i class="icon-angle-right"></i>  मुख्य स्थल  </a></li>
                    </ul>
                </li>
                <li class="panel">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#error-nav">
                        <i class="icon-sitemap"></i>  ग्राम्य व्यवसाय 
       
                        <span class="pull-right">
                            <i class="fa fa-angle-left"></i>
                        </span>
                         
                    </a>
                    <ul class="collapse" id="error-nav">
                        <li><a href="business_intro.php"><i class="icon-angle-right"></i> परिचय  </a></li>
                        <li><a href="business.php"><i class="icon-angle-right"></i>  ग्राम्य व्यवसाय   </a></li>
                    </ul>
                </li>
                
                 <li><a href="gallery.php"><i class="icon-table"></i> Gallery  </a></li>
                 <li><a href="videos.php"><i class="icon-table"></i> Videos  </a></li>
                  <li><a href="message.php"><i class="icon-table"></i> Send Message</a></li>
                   <li><a href="no.php"><i class="icon-table"></i> Send Email  </a></li>
             <li><a href="latest_news.php"><i class="icon-table"></i> ताजा खबरे   </a></li>
             <li><a href="running_programme.php"><i class="icon-table"></i> Running योजनाए </a></li>
             
              <li><a href="jobs.php"><i class="icon-table"></i> नौकरियों  </a></li>
                    
            </ul>

        </div>
        <!--END MENU SECTION -->



        <!--PAGE CONTENT -->
        <div id="content">
             
            <div class="inner" style="min-height: 700px;">
                <?php echo $__env->yieldContent('content'); ?>
                
            </div>

        </div>
        <!--END PAGE CONTENT -->
        <!-- RIGHT STRIP  SECTION -->
        <div id="right">

        <img src="images/dsom.jpg" height="680px" width="200px">            
         

        </div>
         <!-- END RIGHT STRIP  SECTION -->
        
    </div>

    <!--END MAIN WRAPPER -->

    <!-- FOOTER -->
    <div id="footer">
        <p>&copy;  ग्राम पंचायत &nbsp; <?php echo date('Y'); ?></p>
    </div>
    <!--END FOOTER -->


    <!-- GLOBAL SCRIPTS -->
    <script src="<?php echo e(asset('js/jquery-2.0.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/modernizr-2.6.2-respond-1.1.0.min.js')); ?>"></script>
    <!-- END GLOBAL SCRIPTS -->



</body>

    <!-- END BODY -->
</html>
