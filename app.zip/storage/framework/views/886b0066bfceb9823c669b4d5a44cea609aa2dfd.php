<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:40px;">क्रमांक</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Age</th>
                            <th class="text-center">Phone</th>
                            <th class="text-center" >Email</th>
                            <th class="text-center">Pin Code</th>
                            <th class="text-center">Occupation</th>
                            <th class="text-center">Qualification</th>
                            <th class="text-center">Stream</th>
                            <th class="text-center">On</th>
                            <th class="text-center" style="width:100px;">Operation</th>
                        </thead>
                        <tbody>
                           <?php $i = 1; ?>
                            <?php $__currentLoopData = $re; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($loc->name); ?></td>
                                <td><?php echo e($loc->age); ?></td>
                                <td><?php echo e($loc->phone); ?></td>
                                <td><?php echo e($loc->email); ?></td>
                                <td><?php echo e($loc->pin); ?></td>
                                <td><?php echo e($loc->occupation); ?></td>
                                <td><?php echo e($loc->qualification); ?></td>
                                <td><?php echo e($loc->stream); ?></td>
                                <td><?php echo e(date('d F, Y', strtotime($loc->created_at))); ?></td>
                                <td>
                                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['UserRegister@destroy', $loc->id]]); ?>

                                        <button class="btn btn-danger btn-xs pull-left" style="margin-left:10px;"><i class="fa fa-trash"> Delete</i></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>