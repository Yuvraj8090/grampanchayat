<!DOCTYPE html>
<html>
<head> 


    <title>Important Information | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                    <div class="heading_cover_1">
                        सरकार द्वारा चलायी जा रही ऑनलाइन योजनाओं का फायदा उठाये और समय के साथ साथ पैसे भी बचाये |
                    </div>
                    <b>अपनी पेंशन देखने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>
                    <a href="http://ssp.uk.gov.in/reports/PenDetailedInfo.aspx" style="color:blue;">
                        <b>अपनी पेंशन देखे</b>
                    </a>
                    <br/><br/>
                    <b>अपना आधार नंबर की जानकारी देखने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>
                    <a href="https://eaadhaar.uidai.gov.in/" style="color:blue;"><b>अपना आधार नंबर देखे </b></a>
                    <br/><br/>
                    <b>अपना बिजली का बिल ऑनलाइन जमा करने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>
                    <a href="https://www.upcl.org/wss/Login.htm" style="color:blue;"><b>अपना बिजली का बिल जमा करें </b></a>
                    <br/><br/>
                    <b>अपना फ़ोन का बिल ऑनलाइन जमा करने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>
                    <a href="portal.bsnl.in/portal/aspxfiles/login.aspx" style="color:blue;"><b>अपना लैंडलाइन फ़ोन का बिल जमा करे </b></a>
                    <br/><br/>
                     <div class="heading_cover">
                        ग्राम पंचायत में बनने वाले मुख्य प्रमाण पत्र 
                     </div>
                     <b>जाति प्रमाण पत्र हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
        <br/>
        <b>आय प्रमाण पत्र हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
        <br/>
        <b>वृद्धा पेंन्शन हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
            <li>आयु प्रमाण पत्र</li>
        </ol>
        <br/>
        <b>विकलांग पेंन्शन हेतु आवश्यक काकज </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>