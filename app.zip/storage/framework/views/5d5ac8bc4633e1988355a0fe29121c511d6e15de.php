<?php $__env->startSection('content'); ?>

<br />
<?php if(Session::has('insert')): ?>
<div class="alert alert-success">
    <strong> <?php echo e(session('insert')); ?></strong>
</div><br />
<?php endif; ?>

<a style="padding-left:10px;" href="<?php echo e(route('admin-user.create')); ?>" class="btn btn-primary btn-md">
<i class="fa fa-plus fa-fw"></i> Add Panchayat</a>
<a style="padding-left:10px;" href="<?php echo e(url('/panchayat/excel')); ?>" class="btn btn-primary btn-md">
<i class="fa fa-plus fa-fw"></i> Add Panchayats By Excel</a>

<br><br>

<div class="table-responsive">
    <table <?php if(auth()->user()->role_id == 1): ?> style="width:100%;" <?php endif; ?> class="table table-bordered table-striped">
        <thead>
            <th class="text-center">S.No</th>
            <th class="text-center">Panchayat Name</th>
            <th class="text-center">Hindi Name</th>
            <th class="text-center">Email </th>
            <th class="text-center">Phone Number </th>
            <th class="text-center">Action</th>
            <th class="text-center" style="width:10%;">Created At </th>
            <th class="text-center" style="width:15%;">Operation</th>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><a href="http://<?php echo e($users->slug); ?>.grampanchayat.org" target="_blank"><?php echo e($users->name); ?></a></td>
                <td><?php echo e($users->hindi); ?></td>
                <td><?php echo e($users->email); ?></td>
                <td><?php echo e($users->phone); ?></td>
                <td><a href="<?php echo e(route('admin-user.show', $users->id)); ?>" target="_blank"><i class="fa fa-sign-in fa-fw"></i> Login</a></td>
                <td><?php echo e(date('d M, Y', strtotime($users->created_at))); ?></td>
                <td>
                    <a href="<?php echo e(route('admin-user.edit', $users->id)); ?>" class="btn btn-success btn-sm pull-left">
                        <i class="fa fa-edit"></i> Edit</a>
                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUser@destroy', $users->id]]); ?>

                    <button class="btn btn-danger btn-sm pull-left" style="margin-left:10px;"><i class="fa fa-trash"> Delete</i></button>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>