

<?php $__env->startSection('content'); ?>
<br />

<div class="container">
    
    
    <a href="<?php echo e(route('admin-user.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go
        Back</a>
    <br /><br />
    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/change/password')); ?>" method="POST" > 
    
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

    <div class="form-group<?php echo e($errors->has('current_password') ? ' has-error' : ''); ?>">
        <label for="current_password" class="col-md-4 control-label">Current Password</label>

        <div class="col-md-6">
            <input id="current_password" type="text" class="form-control" name="current_password"
                value="<?php echo e(old('current_password')); ?>"  autofocus placeholder="Current Password">

            <?php if($errors->has('current_password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('current_password')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <br /><br /><br />

    <div class="form-group<?php echo e($errors->has('new_password') ? ' has-error' : ''); ?>">
        <label for="new_password" class="col-md-4 control-label">New Password</label>

        <div class="col-md-6">
            <input type="text" class="form-control" name="new_password" value="<?php echo e(old('new_password')); ?>" 
                placeholder="New Password">

            <?php if($errors->has('new_password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('new_password')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <br /><br />
    <div class="form-group<?php echo e($errors->has('confirm_password') ? ' has-error' : ''); ?>">
        <label for="confirm_password" class="col-md-4 control-label">Confirm Password</label>

        <div class="col-md-6">
            <input id="confirm_password" type="text" class="form-control" name="confirm_password" 
                placeholder="Confirm Password">

            <?php if($errors->has('confirm_password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('confirm_password')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <br /><br />


    `<div class="form-group">
        <div class="col-md-6 col-md-offset-4">
            <button type="submit" class="btn btn-primary">
                Submit
            </button>
        </div>
    </div>

    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>