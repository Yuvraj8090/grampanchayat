<!DOCTYPE html>
<html>
<head> 


    <title>Tourist Places | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>


       
        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                    <div class="heading_cover_1">
                        ग्राम पंचायत के मुख्य स्थल और पर्यटक स्थल
                    </div>
                    <p class="para">

                        <?php if($intro): ?>
                         <?php

            $check = $intro->intro;

            $new = preg_replace("/<script\s(.+?)>(.+?)<\/script>/is", "<b>$2</b>", $check);

            $string = preg_replace("/<a\s(.+?)>(.+?)<\/a>/is", "<b>$2</b>", $new);

            echo ($string);

             
             ?>
             <?php else: ?>

             <center>No Record Found</center>


             <?php endif; ?>
                    </p><br/>
                    <?php $__currentLoopData = $place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $places): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <center><img src="/images/<?php echo e($places->image ? $places->image : 'user.jpg'); ?>" class="img-responsive" style="width: 200px;height:150px;"></center>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="heading_cover">
                                <?php echo e($places->name); ?>

                            </div>
                            <p class="para">
                               <?php echo e($places->about); ?>

                            </p>
                        </div>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>