<?php $__env->startSection('content'); ?>

<div class="container">
    <br>
    <a href="<?php echo e(route('admin-user.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br><br>


    <?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br />
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>



    <form action="<?php echo e(url('jan-partinidhi/excel/upload')); ?>" method="POST" enctype="multipart/form-data">

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

        <div class="form-group">
            <label for="exampleInputEmail1">Select Grampanchayat : </label>
            <select class="form-control" name="user">
                <option value="">Select </option>
                <?php if(count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"> <?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <?php if($errors->has('user')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('user')); ?></strong>
            </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1"> Excel File :</label>
            <input type="file" name="file" class="form-control" id="exampleInputPassword1" placeholder="Excel File">
            <?php if($errors->has('file')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('file')); ?></strong>
            </span>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>