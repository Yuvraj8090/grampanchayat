

<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('user-work.create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus fa-fw"></i> Add Video</a>
    <br/><br/>
 
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:80px;">क्रमांक</th>
                            <th class="text-center" style="width:150px;">कार्य का नाम</th>
                            <th class="text-center" style="width:300px;">कार्य के बारेमे </th>
                            <th class="text-center" style="width:150px;">योजना का नाम</th>
                            <th class="text-center" style="width:100px;">वर्ष दिनक</th>
                            <th class="text-center" style="width:80px;">राशि</th>
                            <th class="text-center" style="width:80px;">स्तीथि</th>
                            <th class="text-center" style="width:150px;">Operation</th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                        <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $works): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($works->name); ?></td>
                                <td><?php echo e($works->about); ?></td>
                                <td><?php echo e($works->y_name); ?></td>
                                <td><?php echo e($works->year); ?></td>
                                <td><?php echo e($works->price); ?></td>
                                <td><?php echo e($works->place); ?></td>
                                <td>
                                    <a href="<?php echo e(route('user-work.edit', $works->id)); ?>" class="btn btn-success btn-xs pull-left"><i class="fa fa-edit"></i> Edit</a>
                                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['UserWork@destroy', $works->id]]); ?>

                                        <button class="btn btn-danger btn-xs pull-left" style="margin-left:10px;"><i class="fa fa-trash"></i> Delete</button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>