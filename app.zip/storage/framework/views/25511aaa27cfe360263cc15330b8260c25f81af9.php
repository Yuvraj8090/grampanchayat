

<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-places.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::model($place, ['method'=>'PATCH', 'action'=>['UserPlaces@update', $place->id], 'files'=>true]); ?>


        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <label>नाम:</label>
            <input type="text" name="name" value="<?php echo e($place->name); ?>" class="form-control" required="required" placeholder="नाम">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('about') ? ' has-error' : ''); ?>">
            <label>बारे में:</label>
            <textarea rows="4" name="about" class="form-control" required="required"><?php echo e($place->about); ?></textarea>
            <?php if($errors->has('about')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('about')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <img src="/images/<?php echo e($place->image); ?>" class="img-responsive" style="width:100px;height:100px;">
        </div>
        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
            <label>Image</label>
            <input type="file" name="image">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>