

<?php $__env->startSection('content'); ?>
    <br />

    <?php if(Session::has('insert')): ?>
        <div class="alert alert-success">
            <strong> <?php echo e(session('insert')); ?></strong>
        </div>
        <br />
    <?php endif; ?>

    <a href="<?php echo e(route('user-business-intro.create')); ?>" class="btn btn-primary btn-xs band">
        <i class="fa fa-plus fa-fw"></i> Add
    </a>

    <br />
    <br />
 
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <th class="text-center">परिचय</th>
                <th class="text-center" style="width:100px;">Operation</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $add; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php $check = $address->intro;
                            $new    = preg_replace("/<script\s(.+?)>(.+?)<\/script>/is", "<b>$2</b>", $check);
                            $string = preg_replace("/<a\s(.+?)>(.+?)<\/a>/is", "<b>$2</b>", $new);

                            //echo (substr($string, 0, 400)); ?>

                            <?php echo $string; ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('user-business-intro.edit', $address->id)); ?>" class="btn btn-success btn-xs"><i class="fa fa-edit"></i> Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <style type="text/css">.band{display:none;}#tourist-box{width:auto!important}</style>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>