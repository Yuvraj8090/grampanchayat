<?php $__env->startSection('content'); ?>
<style>
    .card{
        margin:10px;
        border:1px solid black;
        padding:10px 10px;
    }
</style>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


    <div class="card">
          <div class="card-header">
            <h4>Add Title </h4>
          </div>
          <div class="card-body">
                
                <?php if(isset($add->title)): ?>
                    <?php echo Form::open(['method' => 'PATCH', 'action' => ['AdminImportantController@update', $add->id]]); ?>

                <?php else: ?>
                    <?php echo Form::open(['method'=>'POST', 'action'=>'AdminImportantController@store']); ?>

                <?php endif; ?>

                <input type="textbox" class="form-control" name="title"  value="<?php echo e($add->title ?? request()->title ?? ''); ?>"  />
               <br>
                <button type="submit" class="btn btn-sm btn-primary">Submit</button>
            </form>
          </div>
    </div> <br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:40px;">S.No</th>
                            <th class="text-center" style="width:120px;">Point</th>
                            <th class="text-center" style="width:100px;">Created Date</th>
                            <th class="text-center" style="width:120px;">Operation</th>
                        </thead>
                        
                        <tbody>
                            <?php if(count($data) > 0): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->firstItem() + $key); ?></td>
                                        <td><?php echo e($d->title); ?> </td>
                                        <td><?php echo e(date("d,M Y h:i A",strtotime($d->created_at))); ?> </td>
                                         <td>
                                            <a class="btn btn-info btn-sm" href="<?php echo e(route('important.index')); ?>?id=<?php echo e($d->id); ?>">Edit</a>
                                            <a class="btn btn-danger btn-sm" onClick-"return confirm('Are you sure ?')" href="<?php echo e(url('important/delete/'.$d->id)); ?>">Delete</a> 
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(url('points/index/'.$d->id)); ?>">Add Points</a> 
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>