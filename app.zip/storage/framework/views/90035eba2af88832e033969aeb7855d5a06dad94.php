

<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-danger">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('user-email.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::open(['method'=>'POST', 'action'=>'UserEmail@store', 'files'=>true]); ?>


        <div class="form-group<?php echo e($errors->has('to') ? ' has-error' : ''); ?>">
            <label>Send to</label>
            <input type="email" name="to" value="<?php echo e(old('to')); ?>" class="form-control" required="required" placeholder="Send to">
            <?php if($errors->has('to')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('to')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('subject') ? ' has-error' : ''); ?>">
            <label>Subject</label>
           <input type="text" name="subject" placeholder="Subject" class="form-control" required="required">
            <?php if($errors->has('subject')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('subject')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
         <div class="form-group<?php echo e($errors->has('file') ? ' has-error' : ''); ?>">
            <label>Attach file</label>
            <input type="file" name="file">
            <?php if($errors->has('file')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('file')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
            <label>Message</label>
            <textarea rows="4" class="form-control" name="message" required="required" placeholder="Type here"></textarea>
            <?php if($errors->has('message')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('message')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
       
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>