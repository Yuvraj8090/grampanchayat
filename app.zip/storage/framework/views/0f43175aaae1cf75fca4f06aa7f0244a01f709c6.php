<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>tinymce.init({ selector:'.te' });</script>
<style type="text/css">
    #mceu_31
    {
        display:none!important;
    }
</style>
<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-p-message.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::model($msg, ['method'=>'PATCH', 'action'=>['UserPmsg@update', $msg->id], 'files'=>true]); ?>


        <div class="form-group<?php echo e($errors->has('msg') ? ' has-error' : ''); ?>">
            <label>Message</label>
            <input type="text" name="msg" value="<?php echo e($msg->msg); ?>" class="form-control te" style="min-height:400px;">
            <?php if($errors->has('msg')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('msg')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <img src="/images/<?php echo e($msg->image); ?>" class="img-responsive" style="width:200px;height:200px;">
        </div>
        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
            <label>Image</label>
            <input type="file" name="image">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>