<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('admin-user.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
  <?php echo Form::model($user, ['method'=>'PATCH', 'action'=>['AdminUser@update', $user->id]]); ?>


        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Panchayat Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required autofocus placeholder="Panchayat Name">

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br/><br/><br/>
        
        <div class="form-group<?php echo e($errors->has('hindi_name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Panchayat Name Hindi</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="hindi_name" value="<?php echo e($user->hindi); ?>" required placeholder="Panchayat Name Hindi">

                                <?php if($errors->has('hindi_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('hindi_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br/><br/>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required placeholder="E-Mail Address">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
<br/><br/>
                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <label for="phone" class="col-md-4 control-label">Mobile Number</label>

                            <div class="col-md-6">
                                <input id="phone" type="number" class="form-control" name="phone" value="<?php echo e($user->phone); ?>" required placeholder="Mobile Number">

                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

<br/><br/>
<br/>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Update
                                </button>
                            </div>
                        </div>

<?php echo Form::close(); ?>

    </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>