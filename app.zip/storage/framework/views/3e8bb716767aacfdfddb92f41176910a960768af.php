<?php $__env->startSection('content'); ?>

<div class="container">
    <br>
    <a href="<?php echo e(route('admin-user.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>

    <br><br>
    <form action="<?php echo e(url('/jan-partinidhi/update/'.$data->id)); ?>" method="POST">

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

        <div class="form-group">
            <label for="exampleInputEmail1">Select Grampanchayat : </label>
            <select class="form-control" name="user">
                <option value="">Select </option>
                <?php if(count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php if($data->user_id == $user->id): ?> selected <?php endif; ?>> <?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <?php if($errors->has('user')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('user')); ?></strong>
            </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Name : </label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name" value="<?php echo e($data->name); ?>" placeholder="Enter Name">
            <?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Position :</label>
            <input type="text" name="position" class="form-control" id="exampleInputPassword1" value="<?php echo e($data->position); ?>" placeholder="Password">
            <?php if($errors->has('position')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('position')); ?></strong>
            </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Phone No. :</label>
            <input type="number" name="phone" class="form-control" id="exampleInputPassword1" value="<?php echo e($data->phone); ?>" placeholder="Phone No.">
            <?php if($errors->has('phone')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('phone')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Block:</label>
            <input type="text" name="block" class="form-control" id="exampleInputPassword1" value="<?php echo e($data->block); ?>" placeholder="Phone No.">
            <?php if($errors->has('block')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('block')); ?></strong>
            </span>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>