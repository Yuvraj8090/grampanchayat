<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-media.create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus fa-fw"></i> Add Images</a>
    <br/><br/>
 
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <th class="text-center" style="width:80px;">क्रमांक</th>
                            <th class="text-center" style="width:200px;">Image</th>
                            <th class="text-center">Image Name</th>
                            <th class="text-center" style="width:200px;">Operation</th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><img src="/images/<?php echo e($photos->image); ?>" class="img-responsive" title="<?php echo e($photos->alt); ?>" alt="<?php echo e($photos->alt); ?>"></td>
                                <td><?php echo e($photos->alt); ?></td>
                                <td>
                                    
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>