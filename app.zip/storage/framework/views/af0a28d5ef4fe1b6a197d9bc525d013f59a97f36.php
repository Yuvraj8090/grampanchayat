<!DOCTYPE html>
<html>
<head> 


    <title>Gram Panchayat Leaders | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                    <div class="heading_cover_1">
                        ग्राम पंचायत के प्रमुख जन प्रतिनिधि
                    </div>
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <th class="text-center">क्रमांक</th>
                            <th class="text-center">Image</th>
                            <th class="text-center">नाम </th>
                            <th class="text-center">पद </th>
                            <th class="text-center">वार्ड </th>
                            <th class="text-center">फ़ोन नंबर </th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><center><img src="/images/<?php echo e($lists->image ? $lists->image : 'user.jpg'); ?>" class="img-responsive" alt="<?php echo e($lists->name); ?>" style="width:100px;height:100px;"></center></td>
                                <td><?php echo e($lists->name); ?></td>
                                <td><?php echo e($lists->position); ?></td>
                                <td><?php echo e($lists->block); ?></td>
                                <td><?php echo e($lists->phone); ?></td>
                            </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
                    
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>