<!DOCTYPE html>
<html>
<head> 


    <title>Gallery | Gram Panchayat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/css/lightbox.min.css">

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">                   
                    <div class="row">
                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <a href="/images/<?php echo e($photos->image ? $photos->image : 'user.jpg'); ?>" target='_blank' data-lightbox='gram'><img src="/images/<?php echo e($photos->image ? $photos->image : 'user.jpg'); ?>" alt="<?php echo e($photos->alt); ?>" class="img-responsive"></a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/js/lightbox-plus-jquery.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>