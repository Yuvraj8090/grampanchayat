<!DOCTYPE html>
<html>
<head> 


    <title>Register | Gram Panchayat</title>
<style type="text/css">
    label
    {
        margin-top:6px;
    }
</style>
<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                   <?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
                    <h2 style="margin:0px;">Registration Form</h2>
                    <hr/>
                    <?php echo Form::open(['method'=>'POST', 'action'=>'MainIndex@store']); ?>


                    <div class="row<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Full Name</label>
                            <div class="col-md-9">
                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Full Name" required="required">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('age') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Age</label>
                            <div class="col-md-9">
                                <input type="text" name="age" value="<?php echo e(old('age')); ?>" class="form-control" placeholder="Age" required="required">
                                <?php if($errors->has('age')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('age')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Phone Number</label>
                            <div class="col-md-9">
                                <input type="number" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" placeholder="Phone Number" required="required">
                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Email</label>
                            <div class="col-md-9">
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email" required="required">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('pin') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Pin Code</label>
                            <div class="col-md-9">
                                <input type="number" name="pin" value="<?php echo e(old('pin')); ?>" class="form-control" placeholder="Pin Code" required="required">
                                <?php if($errors->has('pin')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pin')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('occupation') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Occupation</label>
                            <div class="col-md-9">
                                <select class="form-control" name="occupation" required="required">
                                    <option><?php echo e(old('occupation')); ?></option>
                                    <option>Government Job</option>
                                    <option>Private Job</option>
                                    <option>Self-Employed</option>
                                    <option>Farmer</option>
                                </select>
                                <?php if($errors->has('occupation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('occupation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('qualification') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Qualification</label>
                            <div class="col-md-9">
                                <select class="form-control" name="qualification" required="required">
                                    <option><?php echo e(old('qualification')); ?></option>
                                    <option>Uneducated</option>
                                    <option>5th</option>
                                    <option>8th</option>
                                    <option>10th</option>
                                    <option>12th</option>
                                    <option>Graduate</option>
                                    <option>Post-Graduate</option>
                                </select>
                                <?php if($errors->has('qualification')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('qualification')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><br/>
                    <div class="row<?php echo e($errors->has('stream') ? ' has-error' : ''); ?>">
                        <div class="form-group">
                            <label class="col-md-3">Stream</label>
                            <div class="col-md-9">
                                <select class="form-control" name="stream" required="required">
                                    <option><?php echo e(old('stream')); ?></option>
                                    <option>Arts</option>
                                    <option>Commerce</option>
                                    <option>Science</option>
                                </select>
                                <?php if($errors->has('stream')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('stream')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group">
                        <center><button class="btn btn-primary btn-sm">Submit</button></center>
                    </div>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <?php echo Form::close(); ?>

                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>