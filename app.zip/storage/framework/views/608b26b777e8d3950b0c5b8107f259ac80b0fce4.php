

<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('user-gallery.create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus fa-fw"></i> Add Images</a>
    <br/><br/>
 
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:80px;">क्रमांक</th>
                            <th class="text-center" style="width:200px;">Image</th>
                            <th class="text-center">Image Name</th>
                            <th class="text-center" style="width:140px;">Operation</th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td>
                                    <center><img src="/images/<?php echo e($photos->image); ?>" class="img-responsive"style="width:80px;height:80px;"></center>
                                </td>
                                <td><?php echo e($photos->alt); ?></td>
                                <td>

                                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['UserGallery@destroy', $photos->id]]); ?>

                                        <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Delete</button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>