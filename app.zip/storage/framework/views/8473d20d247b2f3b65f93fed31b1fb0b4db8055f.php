<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-location.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::model($lo, ['method'=>'PATCH', 'action'=>['UserLocation@update', $lo->id]]); ?>


        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <label>विभाग का नाम:</label>
            <input type="text" name="name" value="<?php echo e($lo->name); ?>" class="form-control" required="required" placeholder="विभाग का नाम">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('place') ? ' has-error' : ''); ?>">
            <label>पता:</label>
            <textarea rows="4" name="place" class="form-control" required="required"><?php echo e($lo->place); ?></textarea>
            <?php if($errors->has('place')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('place')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('distance') ? ' has-error' : ''); ?>">
            <label>दुरी (लगभग) :</label>
            <input type="text" name="distance" class="form-control" value="<?php echo e($lo->distance); ?>" required="required" placeholder="दुरी (लगभग)">
            <?php if($errors->has('distance')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('distance')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>