<!DOCTYPE html>
<html>
<head> 


    <title>Contact Us | Gram Panchayat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/css/lightbox.min.css">
    <style type="text/css">
        iframe{width:100%!important;height:350px!important;}
    </style>
<?php $__env->startSection('content'); ?>
<?php if($add): ?>
        <?php 
        $map = $add->map;

        if (strpos($map, 'https://www.google.com/maps/embed?') == false) 
        {
            echo " <div class='alert alert-danger'>
                <strong> It seems your link is not working! </strong>
          </div>";
        }
        else
        {
            echo $map;   
        }
      ?>
      <?php endif; ?>
        <div class="padding">
            <div class="row">
                <div class="col-md-8">                   
                    <div class="heading_cover">
                         ग्राम पंचायत
                    </div>
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <th class="text-center">पता </th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php if($add): ?><?php echo e($add->address); ?><?php endif; ?></td>
                            </tr>                           
                        </tbody>
                    </table>
                </div>
                <div class="heading_cover">                     
                       ग्राम पंचायत से जनपद स्तर के मुख्य विभाग और उनकी दुरी
                    </div>
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <th class="text-center">क्रमांक </th>
                            <th class="text-center">विभाग का नाम </th>
                            <th class="text-center">पता  </th>
                            <th class="text-center">दुरी (लगभग) </th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $lo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $los): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($los->name); ?> </td>
                                <td><?php echo e($los->place); ?></td>
                                <td><?php echo e($los->distance); ?></td>
                            </tr> 
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                        </tbody>
                    </table>
                </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/js/lightbox-plus-jquery.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>