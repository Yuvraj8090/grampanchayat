
<script src="<?php echo e(asset('js/corp.js')); ?>"></script>
<script src="<?php echo e(asset('js/cp.js')); ?>"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/icropper.css')); ?>">
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-media.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
   

        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
            <label>Choose Image</label>
            <input type="file" name="image" required="required" id="upload">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <div id="upload-demo" style="width:350px;margin-left:2px;"></div>
        </div>
        <div class="form-group">
            <center><a class="btn btn-success btn-sm upload-result">Submit</a></center>
        </div>

  
    </div> 
<script type="text/javascript">
    $.ajaxSetup({
headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
});
$uploadCrop = $('#upload-demo').croppie({
    enableExif: true,
    viewport: {
        width: 1100,
        height: 400,
        type: 'square'
    },
    boundary: {
        width: 1110,
        height: 410
    }
});
$('#upload').on('change', function () { 
    var reader = new FileReader();
    reader.onload = function (e) {
        $uploadCrop.croppie('bind', {
            url: e.target.result
        }).then(function(){
            console.log('jQuery bind complete');
        });
    }
    reader.readAsDataURL(this.files[0]);
    document.getElementById('apbut').style.display = 'block';
});
$('.upload-result').on('click', function (ev) {
    $uploadCrop.croppie('result', {
        type: 'canvas',
        size: 'viewport'
    }).then(function (resp) {
        $.ajax({
            url: "<?php echo e(route('user-media.store')); ?>",
            type: "POST",
            data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                "image":resp
            },
            success: function (data) {
              window.location.href = "/user-media";
            }
        });
    });
});
</script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>