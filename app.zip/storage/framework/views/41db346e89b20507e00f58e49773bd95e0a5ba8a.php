<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-media.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::model($photo, ['method'=>'PATCH', 'action'=>['UserMedia@update', $photo->id], 'files'=>true]); ?>


        <div class="form-group<?php echo e($errors->has('image_name') ? ' has-error' : ''); ?>">
            <label>Image Name</label>
            <input type="text" name="image_name" value="<?php echo e($photo->alt); ?>" placeholder="Image Name" class="form-control" required="required">
            <?php if($errors->has('image_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image_name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><img src="/images/<?php echo e($photo->image); ?>" class="img-responsive" alt="<?php echo e($photo->alt); ?>" style="width:500px;height:500px;"></center>
        </div>
        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
            <label>Choose Image</label>
            <input type="file" name="image">
            <?php if($errors->has('image')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Update</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div>           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>