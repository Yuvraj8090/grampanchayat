<!DOCTYPE html>
<html>
<head> 


    <title>Gram Panchayat Development Works | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-12">
                    <div class="heading_cover_1">
                        ग्राम पंचायत में हुए विकास कार्यो की झलक
                    </div>
                    <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <th class="text-center">क्रमांक</th>
                            <th class="text-center">कार्य का नाम </th>
                            <th class="text-center">कार्य के बारेमे</th>
                            <th class="text-center">योजना का नाम </th>
                            <th class="text-center">वर्ष दिनक </th>
                            <th class="text-center">राशि  </th>
                            <th class="text-center">स्तीथि </th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $works): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($works->name); ?></td>
                                <td><?php echo e($works->about); ?></td>
                                <td><?php echo e($works->y_name); ?></td>
                                <td><?php echo e($works->year); ?></td>
                                <td><?php echo e($works->price); ?></td>
                                <td><?php echo e($works->place); ?></td>
                            </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
                    
                </div>
                
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>