

<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('user-list.create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus fa-fw"></i> Add</a>
    <br/><br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:80px;">क्रमांक</th>
                            <th class="text-center" style="width:150px;">नाम </th>
                            <th class="text-center" style="width:200px;">पद</th>
                            <th class="text-center" style="width:80px;">वार्ड </th>
                            <th class="text-center" style="width:80px;">फ़ोन नंबर</th>
                            <th class="text-center" style="width:100px;">Operation</th>
                        </thead>
                        <tbody>
                           <?php $i = 1; ?>
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($list->name); ?></td>
                                <td><?php echo e($list->position); ?></td>
                                <td><?php echo e($list->block); ?></td>
                                <td><?php echo e($list->phone); ?></td>
                                <td>
                                    <a href="<?php echo e(route('user-list.edit', $list->id)); ?>" class="btn btn-success btn-xs pull-left"><i class="fa fa-edit"></i> Edit</a>
                                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['UserList@destroy', $list->id]]); ?>

                                        <button class="btn btn-danger btn-xs pull-left" style="margin-left:10px;"><i class="fa fa-trash"> Delete</i></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>