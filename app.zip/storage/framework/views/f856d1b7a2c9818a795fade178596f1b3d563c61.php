<!DOCTYPE html>
<html>
<head> 


    <title>Panchayat Business | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                    <div class="heading_cover_1">
                        ग्राम पंचायत में चल रहे मुख्य व्यवसाय 
                    </div>
                    <p class="para">

                        <?php if($intro): ?>
                        <?php

            $check = $intro->intro;

            $new = preg_replace("/<script\s(.+?)>(.+?)<\/script>/is", "<b>$2</b>", $check);

            $string = preg_replace("/<a\s(.+?)>(.+?)<\/a>/is", "<b>$2</b>", $new);

            echo ($string);

             
             ?>
             <?php else: ?>

             <center>No Record Found</center>

             <?php endif; ?>
                    </p><br/>
                    <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businesss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <center><img src="/images/<?php echo e($businesss->image ? $businesss->image : 'user.jpg'); ?>" class="img-responsive" style="width: 200px;height:150px;"></center>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="heading_cover">
                               <?php echo e($businesss->name); ?>

                            </div>
                            <p class="para">
                               <?php echo e($businesss->about); ?>

                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>