<!DOCTYPE html>
<html>
<head> 


    <title>Pradhan Message | Gram Panchayat</title>

<?php $__env->startSection('content'); ?>

        <div class="padding">
            <div class="row">
                <div class="col-md-8">
                    <?php if($msg): ?>
                    <center><img src="/images/<?php echo e($msg->image ? $msg->image : 'user.jpg'); ?>" class="img-responsive" style="width:150px;height:150px;float:left;margin-right:20px;"></center>
                    <?php endif; ?>
                    <p class="para">

                        <?php if($msg): ?>

                         <?php

            $check = $msg->msg;

            $new = preg_replace("/<script\s(.+?)>(.+?)<\/script>/is", "<b>$2</b>", $check);

            $string = preg_replace("/<a\s(.+?)>(.+?)<\/a>/is", "<b>$2</b>", $new);

            echo ($string);

             
             ?>
             <?php else: ?>

             <center>No Record Found</center>

             <?php endif; ?>
</p>

                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('user.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>