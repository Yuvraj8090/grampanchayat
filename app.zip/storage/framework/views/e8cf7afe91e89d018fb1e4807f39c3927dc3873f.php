<?php $__env->startSection('content'); ?>
<br/>
<?php if(Session::has('insert')): ?>
    <div class="alert alert-success">
        <strong> <?php echo e(session('insert')); ?></strong>
    </div><br/>
<?php endif; ?>
<a href="<?php echo e(route('admin-user.create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus fa-fw"></i> Add Panchayat</a>
    <br/><br/>
 
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" style="width:40px;">S.No</th>
                            <th class="text-center" style="width:80px;">Panchayat Name</th>
                            <th class="text-center" style="width:80px;">Hindi Name</th>
                            <th class="text-center" style="width:150px;">Email </th>
                            <th class="text-center" style="width:100px;">Phone Number </th>
                            <th class="text-center" style="width:80px;">Operation</th>
                        </thead>
                        <tbody>
                        	<?php $i = 1; ?>
                           	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><a href="<?php echo e(url('/', $users->slug)); ?>"><?php echo e($users->name); ?></a></td>
                                <td><?php echo e($users->hindi); ?></td>
                                <td><?php echo e($users->email); ?></td>
                                <td><?php echo e($users->phone); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin-user.edit', $users->id)); ?>" class="btn btn-success btn-xs pull-left"><i class="fa fa-edit"></i> Edit</a>
                                     <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUser@destroy', $users->id]]); ?>

                                        <button class="btn btn-danger btn-xs pull-left" style="margin-left:10px;"><i class="fa fa-trash"> Delete</i></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    
            
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>