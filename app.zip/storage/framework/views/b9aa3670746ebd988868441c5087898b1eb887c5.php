<?php $__env->startSection('content'); ?>

                
                <div class="table-responsive">
                    <h4>All Feedbacks : </h4> <br>
                    
                    <br/>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <strong> <?php echo e(session('success')); ?></strong>
                        </div><br/>
                    <?php endif; ?>
                    
                
                    <table <?php if(auth()->user()->role_id == 1): ?> style="width:100%;" <?php endif; ?>  class="table table-bordered table-striped">
                        <thead>
                            <th class="text-center" >S.No</th>
                            <th class="text-center" > Name</th>
                            <th class="text-center" >Email </th>
                            <th class="text-center">Phone Number </th>
                            <th class="text-center" style="width:20%;" >Created At </th>
                            <th class="text-center"  >Operation</th>
                        </thead>
                        <tbody>
                        	<?php $i = 1; ?>
                           	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               <td><?php echo e($key+ 1); ?></td>
                                <td><?php echo e($d->name); ?></td>
                                <td><?php echo e($d->email); ?></td>
                                <td><?php echo e($d->phone); ?></td>
                                <td><?php echo e(date('d M, Y', strtotime($d->created_at))); ?></td>
                                <td>
                        
                                    <a href="<?php echo e(url('/deletefeedback/'.$d->id)); ?>" class="btn btn-danger btn-sm pull-left" style="margin-left:10px;"><i class="fa fa-trash"> Delete</i></a>
                                  
                                </td>
                            </tr>
                            <?php $i++; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>