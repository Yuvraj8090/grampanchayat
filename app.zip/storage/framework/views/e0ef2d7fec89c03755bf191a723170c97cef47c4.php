<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-work.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::model($work, ['method'=>'PATCH', 'action'=>['UserWork@update', $work->id], 'files'=>true]); ?>


        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <label>कार्य का नाम:</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($work->name); ?>" required="required" placeholder="कार्य का नाम">
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('about') ? ' has-error' : ''); ?>">
            <label>कार्य के बारेमे:</label>
            <textarea rows="4" name="about" class="form-control" required="required"><?php echo e($work->about); ?></textarea>
            <?php if($errors->has('about')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('about')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('y_name') ? ' has-error' : ''); ?>">
            <label>योजना का नाम:</label>
            <input type="text" name="y_name" class="form-control" value="<?php echo e($work->y_name); ?>" required="required" placeholder="योजना का नाम">
            <?php if($errors->has('y_name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('y_name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('year') ? ' has-error' : ''); ?>">
            <label>वर्ष:</label>
            <input type="text" name="year" class="form-control" value="<?php echo e($work->year); ?>" required="required" placeholder="वर्ष">
            <?php if($errors->has('year')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('year')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
            <label>राशि:</label>
            <input type="text" name="price" class="form-control" value="<?php echo e($work->price); ?>" required="required" placeholder="राशि">
            <?php if($errors->has('price')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('price')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('place') ? ' has-error' : ''); ?>">
            <label>स्तीथि:</label>
            <select name="place" class="form-control" required="required">
                <option><?php echo e($work->place); ?></option>
                <option>प्रगतिशील</option>
                <option>पूर्ण</option>
            </select>
            <?php if($errors->has('place')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('place')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                   <img src="/images/<?php echo e($work->oldimage); ?>" class="img-responsive" style="width:100px;height:100px;">
                </div>
                <div class="form-group<?php echo e($errors->has('oldimage') ? ' has-error' : ''); ?>">
                    <label>पुराणी फोटो:</label>
                    <input type="file" name="oldimage">
                    <?php if($errors->has('oldimage')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('oldimage')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <img src="/images/<?php echo e($work->newimage); ?>" class="img-responsive" style="width:100px;height:100px;">
                </div>
                <div class="form-group<?php echo e($errors->has('newimage') ? ' has-error' : ''); ?>">
                    <label>नए फोटो:</label>
                    <input type="file" name="newimage">
                    <?php if($errors->has('newimage')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('newimage')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>