<?php $__env->startSection('content'); ?>
<br/>
<a href="<?php echo e(route('user-address.index')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left fa-fw"></i> Go Back</a>
    <br/><br/>
    <div class="container">
    <?php echo Form::open(['method'=>'POST', 'action'=>'UserAddress@store']); ?>


        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
            <label>Address</label>
            <input type="text" name="address" class="form-control" placeholder="Address" required="required">
            <?php if($errors->has('address')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('address')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('map') ? ' has-error' : ''); ?>">
            <label>Map</label>
            <input type="text" name="map" class="form-control" placeholder="Map Link" required="required">
            <?php if($errors->has('map')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('map')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>

    <?php echo Form::close(); ?>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>