<?php 
 //header("content-type: text/html; charset=UTF-8"); 
$con= mysqli_connect("localhost", "root", "","nevi_grampanchayat");
if(!$con)
 {
       die('Could not connect: ' . mysql_connect_error());
 }
      
?>