
    <!-- FOOTER -->
    <div id="footer">
        <p>&copy;  ग्राम पंचायत &nbsp;</p>
    </div>
    <!--END FOOTER -->