
      <!-- RIGHT STRIP  SECTION -->
        <div id="right">

        <img src="banner.jpg" height="680px" width="200px">            
         

        </div>
        <div class="clear"></div>
         <!-- END RIGHT STRIP  SECTION -->
   