<?php include ('header.php'); ?>

<link href="css/banner.css" rel="stylesheet" type="text/css" /> 
<script type="text/javascript" src="../jquery-min.js"></script>
<script type="text/javascript" src="../js/picbox.js"></script>
<link rel="stylesheet" href="../css/picbox.css" type="text/css" media="screen" />

<!--Start Glimmer Insertion-->
<script type='text/javascript' src='../js/jquery-1.3.2.min.js'></script>
<!--glimmer generated file--><script type='text/javascript' src='../js/banner.html.glimmer.js'></script>
<script type="text/javascript" src="../js/jquery-1.9.1.min.js"></script>
		<script type="text/javascript" src="../js/jquery.als-1.2.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function() 
			{
				$("#lista1").als({
					visible_items: 1,
					scrolling_items: 1,
					orientation: "horizontal",
					circular: "yes",
					autoscroll: "yes",
					interval: 5000,
					direction: "right",
					start_from: 1
				});
				
			
				
			
			});
		</script>



<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
                                     
            <div id="contentleft">
			 <h2 align="center"> ग्राम पंचायत की फोटो गैलरी </h2>
			
			<ul>
			 <?php 
            include 'conn.php';
             mysqli_set_charset( $con, 'utf8');
                $sql = "SELECT gallery,alt FROM gallery";
                $result = mysqli_query($con, $sql);
                if (mysqli_num_rows($result) > 0) 
                    {
                        while($row = mysqli_fetch_assoc($result)) 
                        {
                           // echo ' <img src="' . $row['gallery'] . '" alt="image" height="150px" width="150px"/>&nbsp';
                            echo '<li> <a rel="lightbox-demo" href="'.$row['gallery'].'" ><img src="'.$row['gallery'].'" border="0" height="150"  width="150" alt="'.$row['alt'].'"  title="'.$row['alt'].'" /></a></li>';
                        } 
                    }
                else
                {
                    echo "<span style='font-weight:bold;'><center>No Images</center></span>";
                }


        
		
			
		
?>
			<div class="cl"></div>
			
			
			</ul>
			<br/>
	<br/>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
    <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
