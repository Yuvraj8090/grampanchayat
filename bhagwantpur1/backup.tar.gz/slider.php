<!-- Start cssSlider.com -->
	<link rel="stylesheet" href="engine1/style.css">
	<!--[if IE]><link rel="stylesheet" href="engine1/ie.css"><![endif]-->
	<!--[if lte IE 9]><script type="text/javascript" src="engine1/ie.js"></script><![endif]-->
	

	<div class='csslider1 autoplay '>
		<input name="cs_anchor1" id='cs_slide1_0' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_1' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_2' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_3' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_4' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_5' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_6' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_7' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_8' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_9' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_10' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_11' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_12' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_13' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_14' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_play1' type="radio" class='cs_anchor' checked>
		<input name="cs_anchor1" id='cs_pause1_0' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_1' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_2' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_3' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_4' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_5' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_6' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_7' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_8' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_9' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_10' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_11' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_12' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_13' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_14' type="radio" class='cs_anchor pause'>
		
		<ul>
			<div>
				<img src="data1/images/bhagvantpurgrampanchayat.jpg" style="width: 100%;">
			</div>
			<li class='num0 img'>
				<img src='data1/images/bhagvantpurgrampanchayat.jpg' alt='bhagvantpur-grampanchayat' title='bhagvantpur-grampanchayat' />
			</li>
			<li class='num1 img'>
				<img src='data1/images/bhagvantpurgrampanchayatm.jpg' alt='bhagvantpur-grampanchayat-m' title='bhagvantpur-grampanchayat-m' />
			</li>
			<li class='num2 img'>
				<img src='data1/images/bhagvantpurgrampanchayats.jpg' alt='bhagvantpur-grampanchayat-s' title='bhagvantpur-grampanchayat-s' />
			</li>
			<li class='num3 img'>
				<img src='data1/images/bhagvantpurgrampanchayatt.jpg' alt='bhagvantpur-grampanchayat-t' title='bhagvantpur-grampanchayat-t' />
			</li>
			<li class='num4 img'>
				<img src='data1/images/bhagvantpurhimalaybachao.jpg' alt='bhagvantpur-himalay-bachao' title='bhagvantpur-himalay-bachao' />
			</li>
			<li class='num5 img'>
				<img src='data1/images/bhagvantpurschool1.jpg' alt='bhagvantpur-school-1' title='bhagvantpur-school-1' />
			</li>
			<li class='num6 img'>
				<img src='data1/images/grampanchayat.jpg' alt='grampanchayat' title='grampanchayat' />
			</li>
			<li class='num7 img'>
				<img src='data1/images/grampanchayat2.jpg' alt='grampanchayat2' title='grampanchayat2' />
			</li>
			<li class='num8 img'>
				<img src='data1/images/grampanchayatbhagvantpur.jpg' alt='grampanchayat-bhagvantpur' title='grampanchayat-bhagvantpur' />
			</li>
			<li class='num9 img'>
				<img src='data1/images/grampanchayatgp.jpg' alt='grampanchayat-gp' title='grampanchayat-gp' />
			</li>
			<li class='num10 img'>
				<img src='data1/images/grampanchayatharela.jpg' alt='grampanchayat-harela' title='grampanchayat-harela' />
			</li>
			<li class='num11 img'>
				<img src='data1/images/grampanchayatharelapg.jpg' alt='grampanchayat-harela-pg' title='grampanchayat-harela-pg' />
			</li>
			<li class='num12 img'>
				<img src='data1/images/grampanchayatmeeting.jpg' alt='grampanchayat-meeting' title='grampanchayat-meeting' />
			</li>
			<li class='num13 img'>
				<img src='data1/images/grampanchayatvdomeeting.jpg' alt='grampanchayat-vdo-meeting' title='grampanchayat-vdo-meeting' />
			</li>
			<li class='num14 img'>
				<img src='data1/images/grampanchayatwomenjagran.jpg' alt='grampanchayat-women-jagran' title='grampanchayat-women-jagran' />
			</li>
		
		</ul>
		<a class="cs_lnk" href="http://cssslider.com">image slider</a>
		<div class='cs_description'>
			<label class='num0'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-grampanchayat</span></span>
				
			</label>
			<label class='num1'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-grampanchayat-m</span></span>
				
			</label>
			<label class='num2'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-grampanchayat-s</span></span>
				
			</label>
			<label class='num3'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-grampanchayat-t</span></span>
				
			</label>
			<label class='num4'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-himalay-bachao</span></span>
				
			</label>
			<label class='num5'>
				<span class="cs_title"><span class="cs_wrapper">bhagvantpur-school-1</span></span>
				
			</label>
			<label class='num6'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat</span></span>
				
			</label>
			<label class='num7'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat2</span></span>
				
			</label>
			<label class='num8'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-bhagvantpur</span></span>
				
			</label>
			<label class='num9'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-gp</span></span>
				
			</label>
			<label class='num10'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-harela</span></span>
				
			</label>
			<label class='num11'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-harela-pg</span></span>
				
			</label>
			<label class='num12'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-meeting</span></span>
				
			</label>
			<label class='num13'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-vdo-meeting</span></span>
				
			</label>
			<label class='num14'>
				<span class="cs_title"><span class="cs_wrapper">grampanchayat-women-jagran</span></span>
				
			</label>
		</div>
		<div class='cs_play_pause'>
			<label class='cs_play' for='cs_play1'><span><i></i></span></label>
			<label class='cs_pause num0' for='cs_pause1_0'><span><i></i></span></label>
			<label class='cs_pause num1' for='cs_pause1_1'><span><i></i></span></label>
			<label class='cs_pause num2' for='cs_pause1_2'><span><i></i></span></label>
			<label class='cs_pause num3' for='cs_pause1_3'><span><i></i></span></label>
			<label class='cs_pause num4' for='cs_pause1_4'><span><i></i></span></label>
			<label class='cs_pause num5' for='cs_pause1_5'><span><i></i></span></label>
			<label class='cs_pause num6' for='cs_pause1_6'><span><i></i></span></label>
			<label class='cs_pause num7' for='cs_pause1_7'><span><i></i></span></label>
			<label class='cs_pause num8' for='cs_pause1_8'><span><i></i></span></label>
			<label class='cs_pause num9' for='cs_pause1_9'><span><i></i></span></label>
			<label class='cs_pause num10' for='cs_pause1_10'><span><i></i></span></label>
			<label class='cs_pause num11' for='cs_pause1_11'><span><i></i></span></label>
			<label class='cs_pause num12' for='cs_pause1_12'><span><i></i></span></label>
			<label class='cs_pause num13' for='cs_pause1_13'><span><i></i></span></label>
			<label class='cs_pause num14' for='cs_pause1_14'><span><i></i></span></label>
			
		</div>
		<div class='cs_arrowprev'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
			<label class='num4' for='cs_slide1_4'><span><i></i></span></label>
			<label class='num5' for='cs_slide1_5'><span><i></i></span></label>
			<label class='num6' for='cs_slide1_6'><span><i></i></span></label>
			<label class='num7' for='cs_slide1_7'><span><i></i></span></label>
			<label class='num8' for='cs_slide1_8'><span><i></i></span></label>
			<label class='num9' for='cs_slide1_9'><span><i></i></span></label>
			<label class='num10' for='cs_slide1_10'><span><i></i></span></label>
			<label class='num11' for='cs_slide1_11'><span><i></i></span></label>
			<label class='num12' for='cs_slide1_12'><span><i></i></span></label>
			<label class='num13' for='cs_slide1_13'><span><i></i></span></label>
			<label class='num14' for='cs_slide1_14'><span><i></i></span></label>
		</div>
		<div class='cs_arrownext'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
			<label class='num4' for='cs_slide1_4'><span><i></i></span></label>
			<label class='num5' for='cs_slide1_5'><span><i></i></span></label>
			<label class='num6' for='cs_slide1_6'><span><i></i></span></label>
			<label class='num7' for='cs_slide1_7'><span><i></i></span></label>
			<label class='num8' for='cs_slide1_8'><span><i></i></span></label>
			<label class='num9' for='cs_slide1_9'><span><i></i></span></label>
			<label class='num10' for='cs_slide1_10'><span><i></i></span></label>
			<label class='num11' for='cs_slide1_11'><span><i></i></span></label>
			<label class='num12' for='cs_slide1_12'><span><i></i></span></label>
			<label class='num13' for='cs_slide1_13'><span><i></i></span></label>
			<label class='num14' for='cs_slide1_14'><span><i></i></span></label>
		</div>
		
		<div class='cs_bullets'>
			<label class='num0' for='cs_slide1_0'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurgrampanchayat.jpg' alt='bhagvantpur-grampanchayat' title='bhagvantpur-grampanchayat' /></span>
			</label>
			<label class='num1' for='cs_slide1_1'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurgrampanchayatm.jpg' alt='bhagvantpur-grampanchayat-m' title='bhagvantpur-grampanchayat-m' /></span>
			</label>
			<label class='num2' for='cs_slide1_2'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurgrampanchayats.jpg' alt='bhagvantpur-grampanchayat-s' title='bhagvantpur-grampanchayat-s' /></span>
			</label>
			<label class='num3' for='cs_slide1_3'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurgrampanchayatt.jpg' alt='bhagvantpur-grampanchayat-t' title='bhagvantpur-grampanchayat-t' /></span>
			</label>
			<label class='num4' for='cs_slide1_4'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurhimalaybachao.jpg' alt='bhagvantpur-himalay-bachao' title='bhagvantpur-himalay-bachao' /></span>
			</label>
			<label class='num5' for='cs_slide1_5'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/bhagvantpurschool1.jpg' alt='bhagvantpur-school-1' title='bhagvantpur-school-1' /></span>
			</label>
			<label class='num6' for='cs_slide1_6'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayat.jpg' alt='grampanchayat' title='grampanchayat' /></span>
			</label>
			<label class='num7' for='cs_slide1_7'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayat2.jpg' alt='grampanchayat2' title='grampanchayat2' /></span>
			</label>
			<label class='num8' for='cs_slide1_8'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatbhagvantpur.jpg' alt='grampanchayat-bhagvantpur' title='grampanchayat-bhagvantpur' /></span>
			</label>
			<label class='num9' for='cs_slide1_9'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatgp.jpg' alt='grampanchayat-gp' title='grampanchayat-gp' /></span>
			</label>
			<label class='num10' for='cs_slide1_10'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatharela.jpg' alt='grampanchayat-harela' title='grampanchayat-harela' /></span>
			</label>
			<label class='num11' for='cs_slide1_11'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatharelapg.jpg' alt='grampanchayat-harela-pg' title='grampanchayat-harela-pg' /></span>
			</label>
			<label class='num12' for='cs_slide1_12'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatmeeting.jpg' alt='grampanchayat-meeting' title='grampanchayat-meeting' /></span>
			</label>
			<label class='num13' for='cs_slide1_13'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatvdomeeting.jpg' alt='grampanchayat-vdo-meeting' title='grampanchayat-vdo-meeting' /></span>
			</label>
			<label class='num14' for='cs_slide1_14'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/grampanchayatwomenjagran.jpg' alt='grampanchayat-women-jagran' title='grampanchayat-women-jagran' /></span>
			</label>
		</div>
		
		</div>
		<!-- End cssSlider.com -->