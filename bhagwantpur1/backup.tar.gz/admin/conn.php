<?php 
 //header("content-type: text/html; charset=UTF-8"); 
$con= mysqli_connect("localhost", "grampanc_bhag", "admin123$","grampanc_bhagwantpur");
if(!$con)
 {
       die('Could not connect: ' . mysql_connect_error());
 }
      
?>