
       <div id="left" >
            <div class="media user-media well-small">
                <div class="media-body">
                    <h5 class="media-heading" style="font-size:30px;">ग्राम पंचायत</h5>
                    <ul class="list-unstyled user-info">
                        
                        <li>
                             <a class="btn btn-success btn-xs btn-circle" style="width: 10px;height: 12px;"></a> Online
                           
                        </li>
                       
                    </ul>
                </div>
                <br />
            </div>

            <ul id="menu" class="collapse">

                
                <li class="panel active">
                    <a href="index.php" >
                        <i class="icon-table"></i> Dashboard
	   
                       
                    </a>                   
                </li>



                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#component-nav">
                        <i class="icon-tasks"> </i> जनप्रतिनिधि      
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-default">10</span>&nbsp;
                    </a>
                    <ul class="collapse" id="component-nav">
                       
                        <li class=""><a href="janparthinidhi.php"><i class="icon-angle-right"></i> पंचायत स्तर </a></li>
                         <li class=""><a href="icon.html"><i class="icon-angle-right"></i> ब्लॉक स्तर  </a></li>
                        <li class=""><a href="progress.html"><i class="icon-angle-right"></i> जनपद स्तर  </a></li>
                        <li class=""><a href="tabs_panels.html"><i class="icon-angle-right"></i> राज्य  स्तर  </a></li>
                    </ul>
                </li>
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle collapsed" data-target="#form-nav">
                        <i class="icon-pencil"></i> संपर्क 
	   
                        <span class="pull-right">
                            <i class="icon-angle-left"></i>
                        </span>
                          &nbsp; <span class="label label-success">5</span>&nbsp;
                    </a>
                    <ul class="collapse" id="form-nav">
                        <li class=""><a href="address.php"><i class="icon-angle-right"></i> पता  </a></li>
                        <li class=""><a href="location.php"><i class="icon-angle-right"></i> जाने का साधन </a></li>
                    </ul>
                </li>
                <li><a href="vikaskarye.php"><i class="icon-table"></i> विकास कार्य  </a></li>
                 <li><a href="gallery.php"><i class="icon-table"></i> Gallery  </a></li>
                  <li><a href="message.php"><i class="icon-table"></i> Send Message</a></li>
                   <li><a href="email.php"><i class="icon-table"></i> Send Email  </a></li>
            
            </ul>

        </div>
        <!--END MENU SECTION -->
