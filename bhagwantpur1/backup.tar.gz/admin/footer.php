<?php 
        session_start();
     $_SESSION["project"];

        if (empty($_SESSION["project"])) 
        {
            header("Location:index.php");
        }
    ?>
    <!-- FOOTER -->
    <div id="footer">
        <p>&copy;  Bhaji Website wale &nbsp;</p>
    </div>
    <!--END FOOTER -->