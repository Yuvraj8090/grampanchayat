<?php include ('header.php'); ?>


    
        <div id="content">
            
            <div id="contentleft">
               

               
               
                <div style="border: 1px solid #0099FF;">
                   
                    <div id="historymantext">
					
					<iframe width="100%" height="315" src="https://www.youtube.com/embed/TzhOsSCYonM" frameborder="0" allowfullscreen></iframe>
					<br />
					<br />
					<iframe width="100%" height="315" src="https://www.youtube.com/embed/C75qw1zbms0" frameborder="0" allowfullscreen></iframe>
					<br />
					<br />
					<iframe width="100%" height="315" src="https://www.youtube.com/embed/qO4lQcTlcqg" frameborder="0" allowfullscreen></iframe>
					
					</div>
                <div class="cl"></div>
                
                 </div>
            </div>
            <div>
			<div id="contentright">
           <?php include 'rightarea.php'; ?>
		   </div>
        </div>
                <div class="cl"></div>
            
        </div>
        
      <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
