<?php include ('header.php'); ?>

<div id="slider">
        <iframe src="https://www.google.com/maps/d/u/3/embed?mid=1goxxFWpqFzB0Vnr3FEhbFK3uB_U" width="960" height="300"></iframe>		
      </div>   
    
        <div id="content">
            
            <div id="contentleft">
                <h1>भगवन्तपुर ग्राम पंचायत </h1>
                <?php 
                      include 'conn.php' ;
                      mysqli_set_charset( $con, 'utf8');

                      $sql="SELECT id, address FROM address";
                      $result= mysqli_query($con, $sql);
                       $rowcount=mysqli_num_rows($result);


                      if($rowcount)
                        {
                            $result= mysqli_query($con, $sql);
                              
                            echo '<table border="1px" width="auto%" cellpadding="10px">';
                            echo '<tr style="font-weight:bold;font-size:18px;"><td>पता </td></tr>';

                               
                              while($row=mysqli_fetch_assoc($result))                              
                              {
                               
                          
                                  echo '<tr><td>'.$row["address"].'</td></tr>';
                                  
                                
                              } 


                        }
                    else
                          {
                               echo "<span style='font-weight:bold;'><center>No Record Found</center></span>";

                        }

                    echo '</table>'
                    ?>
                
               <h1>भगवन्तपुर ग्राम पंचायत मे पहुचने के साधन</h1>
<table border="1">
    <thead><th>क्रमांक</th><th>मुख्य तथ्य</th></thead>
                   
                <tbody>
                   
                                       <tr><td>1</td><td>देहरादून परैड ग्राउंड  से हर 30 मिनिट में बस सर्विस सायं 7 बजे पुरकुल तक. </td></tr>
                                     
                    
                </tbody>
                </table>

 <h1>भगवन्तपुर ग्राम पंचायत से जनपद स्तर के मुख्य विभाग और उनकी दुरी</h1>
 <?php 
                      include 'conn.php' ;
                      mysqli_set_charset( $con, 'utf8');

                      $sql="SELECT id, name, place, distance FROM location";
                      $result= mysqli_query($con, $sql);
                       $rowcount=@mysqli_num_rows($result);
                      if($rowcount)
                        {
                            $result= mysqli_query($con, $sql);
                              
                            echo '<table border="1px" width="auto%" cellpadding="10px">';
                            echo '<tr style="font-weight:bold;font-size:18px;"><td>क्रमांक</td><td>विभाग का नाम</td><td>पता </td><td> दुरी (लगभग) </td></tr>';

                               $i=1;
                              while($row=mysqli_fetch_assoc($result))                              
                              {
                               
                          
                                  echo '<tr><td>'.$i.'</td><td>'.$row["name"].'</td><td>'.$row["place"].'</td><td>'.$row["distance"].'</td></tr>';
                                  $i++;
                                
                              } 


                        }
                    else
                          {
                               echo "<span style='font-weight:bold;'><center>No Record Found</center></span>";

                        }

                    echo '</table>'
                    ?>

               
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
     <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
