<?php include ('header.php'); ?>
      <div id="touristpage">
          <h2 align="center">   ग्राम पंचायत में हुए विकास कार्यो की झलक</h2>

           <?php 
                      include 'conn.php' ;
                      mysqli_set_charset( $con, 'utf8');

                      $sql="SELECT id, dworkname, about_work, plan_name, year, price, progress_status FROM development_works where ddelete=0";
                      $result= mysqli_query($con, $sql);
                       $rowcount=mysqli_num_rows($result);


                      if($rowcount)
                        {
                            $result= mysqli_query($con, $sql);
                              
                            echo '<table border="1px" width="auto%" cellpadding="10px">';
                            echo '<tr style="font-weight:bold;font-size:18px;"><td>क्रमांक</td><td>कार्य का नाम </td><td> कार्य के बारेमे </td><td>  योजना का नाम</td><td> वर्ष दिनक </td><td>राशि  </td><td>स्तीथि</td></tr>';

                               $i=1;
                              while($row=mysqli_fetch_assoc($result))                              
                              {
                               
                          
                                  echo '<tr><td>'.$i.'</td><td><a href="showdata.php?id='.$row["id"].'">'.$row["dworkname"].'</a></td><td>'.$row["about_work"].'</td><td>'.$row["plan_name"].'</td><td>'.$row["year"].'</td><td>'.$row["price"].'</td><td>'.$row["progress_status"].'</td></tr>';
                                  $i++;
                                
                              } 


                        }
                    else
                          {
                               echo "<span style='font-weight:bold;'><center>no record found please click on add new Record Button</center></span>";

                        }

                    echo '</table>'
                    ?>
 
  <p>नोट: प्रधान जी द्वारा किये गये जनहित  कार्यों का विवरण है, यह एक विकास वर्ष दिखलाता है | ज्यादा जानकारी के लिए प्रधान जी सम्पर्क करे | </p>        
          
       
 	   
          
      </div>
      
          <?php include '../footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
