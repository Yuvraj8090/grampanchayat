<?php include ('header.php'); ?>
      <div id="touristpage">
          <h2 align="center">   ग्राम पंचायत के वीर और साहसी लोग </h2>
<p>उत्तराखंड, उत्तर भारत में स्थित एक बहुत ही खूबसूरत और शांत पर्यटन केंद्र है । इस जगह का शुमार देश की उन चुनिन्दा जगहों में है जोअपनी सुन्दरता के चलते दुनिया भर के पर्यटकों को अपनी ओर आकर्षित करती है।&nbsp; 'देवताओं की भूमि' के रूप में जाना जाने वाला उत्तराखंड अपने शांत वातावरण, मनमोहक दृश्यों और खूबसूरती के कारण पृथ्वी का स्वर्ग माना जाता है।</p>
<p>उत्तराखंड शहीदों की जन्म भूमि तथा कर्मभूमि हैं | यहाँ बहुत से वीर पुरुषों तथा महिलओं ने जन्म लिया है । उत्तराखंड के वीरो से इतिहास भरा हुआ है |</p>

          <div id="tourist-box">
              <div id="touristpageleftbox"><img src="images/brave-people-prithvipur-ten.jpg" height="200" width="200" alt="brave-people-prithvipur-ten" title="brave-people-prithvipur-ten" /></div>
              <div id="touristpagerightbox"><h1>शहीद तेन जेन नमखा </h1>  <strong>शहीद तेन जेन नमखा पुत्र श्री नौरबूडोन्डूप </strong> हमारे ग्राम पंचायत की शान हैं | हम सभी ग्रामवासी उनके बलिदान को हमेशा 
			  याद रखेंगे | कारगिल की जीत में शहीद तेन जेन नमखा के बलिदान को हमेशा याद रखा जायेगा | तेन जेन नमखा  19/07/1999 को कारगिल युद्ध में शहीद हो गये थे | शहीद तेन जेन नमखा 22-5 VIKAS बटालियन के सिपाही थे|
			  हम ऐसा पुत्र को पैदा करने वाली माँ<strong> (तेन जेन सांग्मो ) </strong>को नमन करते हैं |
			  जिसने ऐसे वीर पुरूष को जन्म दिया |
			 </div>
			 
              <div class="cl"></div>
          </div>
          <div id="midabox"> <img src="images/swach-bharat-abhiyan1.jpg" alt="swach-bharat-abhiyan1" /></div>
          

 
          
          
       
 	   
          
      </div>
      
          <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
