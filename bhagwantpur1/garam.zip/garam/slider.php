<div class="slider">
				<div id='hislider1' style="max-width:1000px;  max-height:300px; margin: 0 auto;">
        			<ul style="display: none;overflow: hidden; height: 0; visibility: hidden; opacity: 0;">
						<li>
							<div>
								<img data-src="dataimages/sree.jpg" data-thumb-src="dataimages/sree-th.jpg" title="Bhagvantpur Garam Panchayat" alt="" data-content-type="image" data-content="" data-interval="-1"/>
 								<div data-type="effect" data-effect-type="Fade" data-duration=1500 data-easing="easeInOutQuart"></div>
							</div>
						</li>
						<li>
							<div>
								<img data-src="dataimages/temp.jpg" data-thumb-src="dataimages/temp-th.jpg" title="Bhagvantpur Garam Panchayat" alt="" data-content-type="image" data-content="" data-interval="-1"/>
 								<div data-type="effect" data-effect-type="Fade" data-duration=1500 data-easing="easeInOutQuart"></div>
							</div>
						</li>
						<li>
							<div>
								<img data-src="dataimages/temp2.JPG" data-thumb-src="dataimages/temp2-th.JPG" title="Bhagvantpur Garam Panchayat" alt="" data-content-type="image" data-content="" data-interval="-1"/>
 								<div data-type="effect" data-effect-type="Fade" data-duration=1500 data-easing="easeInOutQuart"></div>
							</div>
						</li>
						<li>
							<div>
								<img data-src="dataimages/temp3.jpg" data-thumb-src="dataimages/temp3-th.jpg" title="Bhagvantpur Garam Panchayat" alt="" data-content-type="image" data-content="" data-interval="-1"/>
 								<div data-type="effect" data-effect-type="Fade" data-duration=1500 data-easing="easeInOutQuart"></div>
							</div>
						</li>
					</ul>
       			</div>
			</div>