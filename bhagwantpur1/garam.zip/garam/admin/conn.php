
<?php
$con= mysqli_connect("localhost", "root", "","admin");
if(!$con)
 {
       die('Could not connect:' . mysql_connect_error());
 }
      
?>