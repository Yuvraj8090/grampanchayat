<?php 
        session_start();
     $_SESSION["project"];

        if (empty($_SESSION["project"])) 
        {
            header("Location:index.php");
        }
    ?>
<input type="file" name="images[]" id="pic1">
<input type="file" name="images[]" id="pic2">
<input type="file" name="images[]" id="pic3">
<input type="file" name="images[]" id="pic4">
<input type="file" name="images[]" id="pic5">
<input type="file" name="images[]" id="pic6">
<input type="file" name="images[]" id="pic7">
<input type="file" name="images[]" id="pic8">
<php?
 $file_exts = array("jpg", "bmp", "jpeg", "gif", "png");
    $max = NULL;
    if(isset($_FILES['images']['name']) )
    {
    $max = count( $_FILES['images']['name'] );
    } 
      if($max > 0)
    {
  echo "<table><tr><td colspan=3>The following images have been uploaded</td></tr>\n"; 
  
	for ( $counter = 0; $counter < $max; $counter++)
	{
	  $name = $_FILES['images']['name'][$counter];
	  $type = $_FILES['images']['type'][$counter];
	  $tmp  = $_FILES['images']['tmp_name'][$counter];
	  $error = $_FILES['images']['error'][$counter];
	  $size  = round($_FILES['images']['size'][$counter] / 1024,2);
  
    echo '<tr><td rowspan="4"><img src="/providers/'.$dbh->lastInsertId().'/'.$name.'"></td>';
    echo '<td>Name</td><td>'.$name.'</td></tr>';
    echo '<tr><td>Type</td><td>'.$type.'</td></tr>';
    echo '<tr><td>Size</td><td>'.$size.'</td></tr>';
  
	  move_uploaded_file($_FILES["images"]["tmp_name"][$counter],
	  "/home/luke69/public_html/providers/{$dbh->lastInsertId()}/" . $_FILES["images"]["name"][$counter]);
  
	}
    echo "</table>";
  }
 ?>