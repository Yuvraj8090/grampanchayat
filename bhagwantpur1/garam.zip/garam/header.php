<!DOCTYPE html>
<html>
<head>
	<title>Bhagvantpur Garam Panchayat</title>
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script type="text/javascript" src="sliderengine/jquery.js"></script><script type="text/javascript" src="sliderengine/jquery.hislider.js"></script>
	<META NAME="Author" CONTENT="Universal Web Solutions">
    <META NAME="Subject" CONTENT="Bhagvantpur Gram Panchayat, Uttarakhand">
    <META NAME="Description" CONTENT="Welcome to Bhagvantpur gram panchayat. it is a first website of Bhagvantpur gram panchayat. it is made by gram pradhan.  ">
    <META NAME="Keywords" CONTENT="Bhagvantpur Gram Panchayat,Bhagvantpur gram panchayat,Bhagvantpur gram panchayat dehradun ,Bhagvantpur gram panchayat vikasnagar ,uttarakhand gram panchayat,gram panchyat  provide best facility for accomdation">
    <META NAME="Generator" CONTENT="Universal Web Solutions">
    <META NAME="Language" CONTENT="English">
</head>
<body>
	<div class="main">
		<div class="inner_box">
			<div class="header">
				<div class="top_header">
					<div class="top_box">
						<a href=""><div class="t"><img src="images/facebook.png" width="30px" height="30px" alt="Facebook"></div></a>
						<a href=""><div class="t"><img src="images/twitter.png" width="30px" height="30px" alt="Twitter"></div></a>
						<a href=""><div class="t"><img src="images/youtube.png" width="30px" height="30px" alt="Youtube"></div></a>
						<a href=""><div class="t"><img src="images/google.ico" width="30px" height="30px" alt="Google+"></div></a>
					</div>
					<div class="top_box_right">
						<a href="Register.php">Register&nbsp</a> |
						<a href="gram-panchayat-development-works.php">विकास कार्य&nbsp</a> |
						<a href="important-information.php">&nbspमहत्वपूर्ण जानकारी</a>
					</div>
					<div class="clear"></div>
				</div>
				<div class="middle_header">
					<div class="head">भगवन्तपुर ग्राम पंचायत</div>
					<div class="head2"><img src="images/logo.jpg" alt="Logo" height="100px" width="450px"></div>
					<div class="clear"></div>
				</div>
				<div class="lower_header">
					<div class="menu">
						<ul>
							<li><a href="index.php" class="a">होम </a></li>
							<li><a href="pradhan-message.php" class="a">प्रधान सन्देश</a></li>
							<li><a href="tourist-place.php" class="a">मुख्य स्थल</a></li>
							<li><a href="gallery.php" class="a">गैलरी </a></li>
							<li><a href="videos.php" class="a">वीडियो </a></li>
							<li><a href="panchyat-business.php" class="a">ग्राम्य व्यवसाय</a></li>
							<li><a href="gram-panchayat-leaders.php" class="a">पंचायत प्रतिनिधि</a></li>
							<li><a href="" class="a">वीर महिला / पुरुष</a></li>
							<li><a href="contact_us.php" class="a">संपर्क </a></li>
							<div class="clear"></div>
						</ul>
					</div>
				</div>
			</div>