<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>


                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td>श्री रविन्द्र सिंह</td><td> प्रधान</td><td> 10</td><td>+91- </td></tr>
                    <tr><td>1</td><td>श्री  शशी कांत</td><td> सदस्य</td><td> -</td><td>+91-7557576383</td></tr>
                    <tr><td>2</td><td>श्रीमती सुनीता जोशी </td><td> सदस्य</td><td> -</td><td>+91-9258718363</td></tr>
                    <tr><td>3</td><td>श्रीमती सरिता देवी </td><td> सदस्य</td><td> -</td><td>+91-9997170252</td></tr>
                    <tr><td>4</td><td>श्री विजय रावत  </td><td> सदस्य</td><td> -</td><td>+91-9837362383</td></tr>
                    <tr><td>5</td><td>श्री गौरव जोशी </td><td> सदस्य</td><td> -</td><td>+91-9410539996</td></tr>
                    <tr><td>6</td><td>श्रीमती कुषुम देवी  </td><td> सदस्य</td><td> -</td><td>+91-8941946140</td></tr>
                    <tr><td>8</td><td>प्रीती रतूड़ी </td><td> सदस्य</td><td> -</td><td>+91-9411312592</td></tr>
                    <tr><td>9</td><td>रानी गुरुंग </td><td> सदस्य</td><td> -</td><td>+91-9719032859</td></tr>
                    <tr><td>10</td><td>श्री विजय पाण्डेय  </td><td> सदस्य</td><td> -</td><td>+91-7579025015</td></tr>
                    <tr><td>11</td><td>श्रीमती रेणु पाल </td><td> सदस्य</td><td> -</td><td>+91-9690770329</td></tr>
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
      <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
