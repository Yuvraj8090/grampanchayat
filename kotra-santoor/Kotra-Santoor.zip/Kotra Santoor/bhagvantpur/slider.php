<link rel="stylesheet" href="engine1/style.css">
	<!--[if IE]><link rel="stylesheet" href="engine1/ie.css"><![endif]-->
	<!--[if lte IE 9]><script type="text/javascript" src="engine1/ie.js"></script><![endif]-->
	

	<div class='csslider1 autoplay '>
		<input name="cs_anchor1" id='cs_slide1_0' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_1' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_2' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_3' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_play1' type="radio" class='cs_anchor' checked>
		<input name="cs_anchor1" id='cs_pause1_0' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_1' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_2' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_3' type="radio" class='cs_anchor pause'>
		
		<ul>
			<div>
				<img src="data1/images/green_view_kotra_gram_sabha.jpg" style="width: 100%;">
			</div>
			<li class='num0 img'>
				<img src='data1/images/green_view_kotra_gram_sabha.jpg' alt='green_view_kotra_gram_sabha' title='green_view_kotra_gram_sabha' />
			</li>
			<li class='num1 img'>
				<img src='data1/images/kotra_grampanchayt_devlopme.jpg' alt='kotra_grampanchayt_devlopme' title='kotra_grampanchayt_devlopme' />
			</li>
			<li class='num2 img'>
				<img src='data1/images/kotra_grampanchayt_mandir.jpg' alt='kotra_grampanchayt_mandir' title='kotra_grampanchayt_mandir' />
			</li>
			<li class='num3 img'>
				<img src='data1/images/mandir_kotra_grampanchayt.jpg' alt='mandir_kotra_grampanchayt' title='mandir_kotra_grampanchayt' />
			</li>
		
		</ul>
		<a class="cs_lnk" href="http://cssslider.com">image slider</a>
		<div class='cs_description'>
			<label class='num0'>
				<span class="cs_title"><span class="cs_wrapper">green_view_kotra_gram_sabha</span></span>
				
			</label>
			<label class='num1'>
				<span class="cs_title"><span class="cs_wrapper">kotra_grampanchayt_devlopme</span></span>
				
			</label>
			<label class='num2'>
				<span class="cs_title"><span class="cs_wrapper">kotra_grampanchayt_mandir</span></span>
				
			</label>
			<label class='num3'>
				<span class="cs_title"><span class="cs_wrapper">mandir_kotra_grampanchayt</span></span>
				
			</label>
		</div>
		<div class='cs_play_pause'>
			<label class='cs_play' for='cs_play1'><span><i></i></span></label>
			<label class='cs_pause num0' for='cs_pause1_0'><span><i></i></span></label>
			<label class='cs_pause num1' for='cs_pause1_1'><span><i></i></span></label>
			<label class='cs_pause num2' for='cs_pause1_2'><span><i></i></span></label>
			<label class='cs_pause num3' for='cs_pause1_3'><span><i></i></span></label>
			
		</div>
		<div class='cs_arrowprev'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
		</div>
		<div class='cs_arrownext'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
		</div>
		
		<div class='cs_bullets'>
			<label class='num0' for='cs_slide1_0'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/green_view_kotra_gram_sabha.jpg' alt='green_view_kotra_gram_sabha' title='green_view_kotra_gram_sabha' /></span>
			</label>
			<label class='num1' for='cs_slide1_1'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/kotra_grampanchayt_devlopme.jpg' alt='kotra_grampanchayt_devlopme' title='kotra_grampanchayt_devlopme' /></span>
			</label>
			<label class='num2' for='cs_slide1_2'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/kotra_grampanchayt_mandir.jpg' alt='kotra_grampanchayt_mandir' title='kotra_grampanchayt_mandir' /></span>
			</label>
			<label class='num3' for='cs_slide1_3'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/mandir_kotra_grampanchayt.jpg' alt='mandir_kotra_grampanchayt' title='mandir_kotra_grampanchayt' /></span>
			</label>
		</div>
		
		</div>
