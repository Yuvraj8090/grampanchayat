<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td> निशा</td><td> प्रधान</td><td> -</td><td>+91-9997214314</td></tr>
					<tr><td>2</td><td>किरण थापली</td><td>  उपप्रधान</td><td> 6</td><td>+91-9761597266</td></tr>
                    <tr><td>3</td><td>रेशमी रावत</td><td> सदस्य</td><td>1</td><td>+91-7310597266</td></tr>
                    <tr><td>4</td><td>मुन्ना रावत</td><td> सदस्य</td><td> 2</td><td>+91-9760632013</td></tr>
                    <tr><td>5</td><td>ममता थापली</td><td> सदस्य</td><td> 3</td><td>+91-8755113340</td></tr>
                    <tr><td>6</td><td>बबिता कोहली</td><td> सदस्य</td><td> 4</td><td>+91-8126039011</td></tr>
					<tr><td>7</td><td>कृष्णा</td><td> सदस्य</td><td> 5</td><td>+91-</td></tr>
					<tr><td>8</td><td>रुक्मणी थापाली</td><td> सदस्य</td><td> 6</td><td>+91-7088073857</td></tr>
					<tr><td>8</td><td>गोविंद रावत</td><td> सदस्य</td><td> 7</td><td>+91-8171257236</td></tr>
					<tr><td>8</td><td>मोहनलाल</td><td> सदस्य</td><td> 9</td><td>+91-7088475128</td></tr>
				
				
				
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
