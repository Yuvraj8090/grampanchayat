<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td>विरेन्द्र सिंह </td><td> प्रधान</td><td>07 </td><td>+91-8057570794</td></tr>
                    <tr><td>2</td><td>मंजीत सिंह</td><td> उप-प्रधान</td><td> 06</td><td>9639284589</td></tr>
                    <tr><td>3</td><td>सीता देवी </td><td> सदस्य</td><td> 01</td><td>-</td></tr>
                    <tr><td>4</td><td>सुशीला देवी</td><td> सदस्य</td><td> 2</td><td>-</td></tr>
                    <tr><td>5</td><td>राम प्रकाश</td><td> सदस्य</td><td> 3</td><td>9917430729</td></tr>
                    <tr><td>6</td><td>खेम सिंह </td><td> सदस्य</td><td> 4</td><td>-</td></tr>
					<tr><td>7</td><td>शभुवनेश्वरी देवी</td><td> सदस्य</td><td> 5</td><td>-</td></tr>
					<tr><td>8</td><td>सीमा देवी</td><td> सदस्य</td><td> 6</td><td>-</td></tr>
					
					
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
    <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
