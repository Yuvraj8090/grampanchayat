<div class="footer">
				<p>Design and Develop by - Jatin Jangra || Hosting - <a href="">www.universalwebsolutions.in</a></p><br/>
				<p>अपनी ग्राम पंचायत को हमसे जोड़ने और ग्राम पंचायत की वेबसाइट बनवाने के लिए सम्पर्क करे ! विकास शर्मा -- +91-9634039666</p>
				<p>अपने बिज़नस, कॉलेज, स्कूल, कोचिंग सेन्टर, फर्म, की वेबसाइट बनवाने के लिए संपर्क करे - +91-9634039666 | +91- 94-1010-2425</p>
			</div>
		</div>
	</div>
</body>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/js/lightbox-plus-jquery.min.js"></script>
</html>