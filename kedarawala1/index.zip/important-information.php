<?php 
	include "header.php";
?>
<div class="body"><br/>
	<div class="left_box">
		<div class="heading" style="background-color:#FB9943;font-size:18px;width:auto;">सरकार द्वारा चलायी जा रही ऑनलाइन योजनाओं का फायदा उठाये और समय के साथ साथ पैसे भी बचाये |</div><br/>&nbsp&nbsp
		<b>अपनी पेंशन देखने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>&nbsp&nbsp
        <a href="http://ssp.uk.gov.in/reports/PenDetailedInfo.aspx" style="color:blue;"><b>अपनी पेंशन देखे</b></a>
        <br/><br/>&nbsp&nbsp
        <b>अपना आधार नंबर की जानकारी देखने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>&nbsp&nbsp
        <a href="https://eaadhaar.uidai.gov.in/" style="color:blue;"><b>अपना आधार नंबर देखे </b></a>
        <br/><br/>&nbsp&nbsp
        <b>अपना बिजली का बिल ऑनलाइन जमा करने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>&nbsp&nbsp
        <a href="https://www.upcl.org/wss/Login.htm" style="color:blue;"><b>अपना बिजली का बिल जमा करें </b></a>
        <br/><br/>&nbsp&nbsp
        <b>अपना फ़ोन का बिल ऑनलाइन जमा करने के लिए नीचे दिए गये लिंक पर क्लिक करे </b><br/>&nbsp&nbsp
        <a href="portal.bsnl.in/portal/aspxfiles/login.aspx" style="color:blue;"><b>अपना लैंडलाइन फ़ोन का बिल जमा करे </b></a>
        <div class="heading" style="margin-top:20px;">ग्राम पंचायत में बनने वाले मुख्य प्रमाण पत्र </div><br/>&nbsp&nbsp
        <b>जाति प्रमाण पत्र हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
        <br/>&nbsp&nbsp
        <b>आय प्रमाण पत्र हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
        <br/>&nbsp&nbsp
        <b>वृद्धा पेंन्शन हेतु आवश्यक </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
            <li>आयु प्रमाण पत्र</li>
        </ol>
        <br/>&nbsp&nbsp
        <b>विकलांग पेंन्शन हेतु आवश्यक काकज </b>
        <ol>
            <li>प्रधान प्रमाणित प्रमाण पत्र</li>
            <li>परिवार रजिस्टर की नक़ल</li>
            <li>राशन कार्ड</li>
            <li>पहचान पत्र</li>
        </ol>
	</div>
<?php 
	include 'rightbox.php';
?>
	<div class="clear"></div>
</div>
<?php 
	include 'footer.php';
?>