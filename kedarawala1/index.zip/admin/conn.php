
<?php
$con= mysqli_connect("localhost", "root", "","kedarawala_grampanchayat");
if(!$con)
 {
       die('Could not connect:' . mysql_connect_error());
 }
      
?>