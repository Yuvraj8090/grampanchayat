<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td> मेहमूदा</td><td> प्रधान</td><td> -</td><td>+91-9412003527</td></tr>
					<tr><td>2</td><td>नरेन्द्र सिंह नेगी</td><td>  उपप्रधान</td><td> 1</td><td>+91-9759838221</td></tr>
                    <tr><td>3</td><td>हेमलता देवी </td><td> सदस्य</td><td>2</td><td>+91-9557669109</td></tr>
                    <tr><td>4</td><td>गीता असवाल  </td><td> सदस्य</td><td> 3</td><td>+91-9719077104</td></tr>
                    <tr><td>5</td><td>मो० सालिक</td><td> सदस्य</td><td> 4</td><td>+91-9719628577</td></tr>
                    <tr><td>6</td><td>अल्ताफ हुसेन</td><td> सदस्य</td><td> 5</td><td>9837704950</td></tr>
					<tr><td>7</td><td>अरुणा नेगी</td><td> सदस्य</td><td>6</td><td>+91-9536760502</td></tr>
                    <tr><td>8</td><td>सन्दीप </td><td> सदस्य</td><td> 7</td><td>+91-9634765522</td></tr>
                    <tr><td>9</td><td>बबली देवी पंवार</td><td> सदस्य</td><td> 8</td><td>+91-9557283066</td></tr>
                    <tr><td>10</td><td>राकेश</td><td> सदस्य</td><td> 9</td><td>9720608266</td></tr>
					<tr><td>11</td><td>सविता देवी </td><td> सदस्य</td><td>10</td><td>+91-8126523726</td></tr>
                    <tr><td>12</td><td>राजेश्वरी </td><td> सदस्य</td><td> 11</td><td>+91-8126879985</td></tr>
                    <tr><td>13</td><td>दयाराम</td><td> सदस्य</td><td> 12</td><td>+91-9997264240</td></tr>
                    <tr><td>14</td><td>अजय कुमार</td><td> सदस्य</td><td> 13</td><td>+91-9412148428</td></tr>
					<tr><td>15</td><td>कालू देवी </td><td> सदस्य</td><td>14</td><td>+91-9927450033</td></tr>
                    <tr><td>16</td><td>जितेन्द्र धियानी </td><td> सदस्य</td><td> 15</td><td>+91-9410901642</td></tr>
                    
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
