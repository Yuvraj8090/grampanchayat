<?php include ('header.php'); ?>

<div id="slider">
        <iframe src="https://www.google.com/maps/d/u/3/embed?mid=1goxxFWpqFzB0Vnr3FEhbFK3uB_U" width="960" height="300"></iframe>		
      </div>   
    
        <div id="content">
            
            <div id="contentleft">
                <h1>लाडपुर ग्राम पंचायत </h1>
                <p>लाडपुर ग्राम पंचायत <br />
               ग्राम प्रधान <br/>
                   <strong> घनश्याम पाल </strong><br />
               फ़ोन नंबर - +91-9412975220<br />
               </p>
                
               <h1>लाडपुर ग्राम पंचायत मे पहुचने के साधन</h1>
<table border="1">
    <thead><th>क्रमांक</th><th>मुख्य तथ्य</th></thead>
                   
                <tbody>
                   
                                       <tr><td>1</td><td>देहरादून परैड ग्राउंड  से हर 30 मिनिट में बस सर्विस सायं 7 बजे लाडपुर तक. </td></tr>
                                     
                    
                </tbody>
                </table>

 <h1>लाडपुर ग्राम पंचायत से जनपद स्तर के मुख्य विभाग और उनकी दुरी</h1>
<table border="1">
    <thead><th>विभाग  का नाम</th><th>पता</th><th>दुरी (लगभग)</th</thead>
                   
                <tbody>
                   
                    <tr><td>ब्लाक </td><td> रायपुर </td><td>5 किमी.</td></</tr>
                    <tr><td>सरकारी अस्पताल  </td><td>लाडपुर</td><td>  0 किमी.</td></tr>
                    <tr><td>दून अस्पताल</td><td>Court Road, Dehradun, Uttarakhand</td><td>6 किमी.</td></tr> 
                    <tr><td>सचिवालय</td><td>4 Subash Road, Uttarakhand Secretariat, Fourth Floor New Building, Dehradun, Uttarakhand 248001</td><td> 7 किमी.</td></tr>

<tr><td>जिला पंचायत कार्यालय देहरादून(DPRO)</td><td>Near survey chowk Dehradun </td><td>7 किमी.</td></tr>
<tr><td>विकास भवन</td><td>Near survey chowk Dehradun </td><td> 6 किमी.</td></tr>
<tr><td>समाज कल्याण विभाग</td><td>Near ITI Building, Survey Chowk,Dehradun. </td><td>6  किमी.</td></tr>
<tr><td>पशु सेवा केंद्र</td><td> देहरादून. </td><td>4 किमी.</td></tr>
<tr><td>रेलवे स्टेशन</td><td>सहारनपुर रोड  </td><td>7 किमी.</td></tr>
<tr><td>ISBT</td><td>ISBT देहरादून </td><td>13  किमी.</td></tr>
<tr><td>हवाई अड्डा </td><td>जौली ग्रांट रानीपोखरी  देहरादून </td><td>30 किमी.</td></tr>
<tr><td>पुलिस चोकी/ थाना</td><td>राजपुर देहरादून</td><td>500 मी.</td></tr>


                    
                </tbody>
                </table>

               
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
     <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
