<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td>घनश्याम पाल  </td><td> प्रधान</td><td>07 </td><td>+91-9412975220</td></tr>
                    <tr><td>2</td><td>पंकज झा</td><td> उप-प्रधान</td><td> 05</td><td>-</td></tr>
                    <tr><td>3</td><td>अनिता घिल्डियाल </td><td> सदस्य</td><td> 01</td><td>-</td></tr>
                    <tr><td>4</td><td>राजविन्दर कौर</td><td> सदस्य</td><td> 2</td><td>-</td></tr>
                    <tr><td>5</td><td>विजेता राना</td><td> सदस्य</td><td> 3</td><td>-</td></tr>
                    <tr><td>6</td><td>अनिता रावत</td><td> सदस्य</td><td> 4</td><td>-</td></tr>
					<tr><td>7</td><td>गणेश थापा</td><td> सदस्य</td><td> 6</td><td>9319703472</td></tr>
					<tr><td>8</td><td>दीपक जोशी</td><td> सदस्य</td><td> 7</td><td>9997981133</td></tr>
					<tr><td>9</td><td>कु० प्रियंक सूद</td><td> सदस्य</td><td> 8 </td><td>-</td></tr>
					<tr><td>10</td><td>आदित्य त्यागी</td><td> सदस्य</td><td> 9 </td><td>-</td></tr>
					<tr><td>11</td><td>आशिया बेगम</td><td> सदस्य</td><td> 10 </td><td>9557873792</td></tr>
					<tr><td>12</td><td>मुकेश कुमार</td><td> सदस्य</td><td> 11</td><td>9761424707</td></tr>
					<tr><td>13</td><td>रेखा शर्मा</td><td> सदस्य</td><td> 12</td><td>-</td></tr>
					<tr><td>14</td><td>सुमन थपलियाल</td><td> सदस्य</td><td> 13</td><td>-</td></tr>
					<tr><td>15</td><td>रेखा रानी</td><td> सदस्य</td><td> 14</td><td>9675788690</td></tr>
					<tr><td>16</td><td>विजय कुमार मौर्य</td><td> सदस्य</td><td> 15</td><td>8126044318</td></tr>
					
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
    <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
