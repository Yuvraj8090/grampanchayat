<?php include ('header.php'); ?>
      <div id="touristpage">
          <h2 align="center">   ग्राम पंचायत के मुख्य स्थल और पर्यटक स्थल</h2>
<p>उत्तराखंड, उत्तर भारत में स्थित एक बहुत ही खूबसूरत और शांत पर्यटन केंद्र है । इस जगह का शुमार देश की उन चुनिन्दा जगहों में है जोअपनी सुन्दरता के चलते दुनिया भर के पर्यटकों को अपनी ओर आकर्षित करती है।&nbsp; 'देवताओं की भूमि' के रूप में जाना जाने वाला उत्तराखंड अपने शांत वातावरण, मनमोहक दृश्यों और खूबसूरती के कारण पृथ्वी का स्वर्ग माना जाता है।</p>
          <div id="tourist-box">
              <div id="touristpageleftbox"><img src="images/ladpur-kali-mata-mandir.jpg" height="200" width="200" /></div>
              <div id="touristpagerightbox"><h1>प्राचीन काली माता मंदिर </h1>ग्राम पंचायत में एक काली माता मंदिर   है  इसकी यहाँ बहुत मान्यता है, यहाँ काफी लोग आते हैं और मनोकामना को पूर्ण करने की कामना करते हैं.</div>
              <div class="cl"></div>
          </div>
          
          <div id="tourist-box1">
              <div id="touristpageleftbox1"> <h1>शिव जी का मंदिर </h1>यह एक अति प्राचीन शिव जी  का मंदिर है यह लगभग 15 वर्ष पुराना है</div>
              <div id="touristpagerightbox1"><img src="images/ladpur-shiv-mandir.jpg" height="200" width="200" /> </div>
              <div class="cl"></div>
          </div>

          
          
          
          
          
      </div>
      
          <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
