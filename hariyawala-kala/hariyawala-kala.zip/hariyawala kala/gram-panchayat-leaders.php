<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>


                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td>श्री अशोक नेगी </td><td> प्रधान</td><td> -</td><td>+91-9719676850 </td></tr>
                    <tr><td>1</td><td>श्रीमती रीता	 </td><td> सदस्य</td><td> -</td><td>+91- 7500672157</td></tr>
                    <tr><td>2</td><td>श्रीमती बालू देवी  </td><td> सदस्य</td><td> -</td><td>+91- 8126301536</td></tr>
                    <tr><td>3</td><td>श्रीमती बबली देवी </td><td> सदस्य</td><td> -</td><td>+91-9760508221</td></tr>
                    <tr><td>4</td><td>श्रीमती  प्रीति</td><td> सदस्य</td><td> -</td><td>+91-7895742193</td></tr>
                    <tr><td>5</td><td>श्रीमती  निर्मला बिष्ट</td><td> सदस्य</td><td> -</td><td>+91-</td></tr>
                    <tr><td>6</td><td>श्री मनोज धिमान  </td><td> सदस्य</td><td> -</td><td>+91-7895317926</td></tr>
                    <tr><td>8</td><td>श्री संदीप नेगी  </td><td> सदस्य</td><td> -</td><td>+91-9410165185</td></tr>
                    <tr><td>9</td><td>श्री रोशन लाल </td><td> सदस्य</td><td> -</td><td>+91-8650558897</td></tr>
                    
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
             <div>
           <?php include 'rightarea.php'; ?>
        </div>
            <div class="cl"></div>
            
        </div>
        
      <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
