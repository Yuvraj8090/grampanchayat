<link rel="stylesheet" href="engine1/style.css">
	<!--[if IE]><link rel="stylesheet" href="engine1/ie.css"><![endif]-->
	<!--[if lte IE 9]><script type="text/javascript" src="engine1/ie.js"></script><![endif]-->
	

	<div class='csslider1 autoplay '>
		<input name="cs_anchor1" id='cs_slide1_0' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_1' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_2' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_3' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_play1' type="radio" class='cs_anchor' checked>
		<input name="cs_anchor1" id='cs_pause1_0' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_1' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_2' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_3' type="radio" class='cs_anchor pause'>
		
		<ul>
			<div>
				<img src="data1/images/chandrotdevlopment.jpg" style="width: 100%;">
			</div>
			<li class='num0 img'>
				<img src='data1/images/chandrotdevlopment.jpg' alt='chandrot-devlopment' title='chandrot-devlopment' />
			</li>
			<li class='num1 img'>
				<img src='data1/images/chandrotigrampanchayat.jpg' alt='chandroti-grampanchayat' title='chandroti-grampanchayat' />
			</li>
			<li class='num2 img'>
				<img src='data1/images/chandrotigrampanchyatview.jpg' alt='chandroti-grampanchyat-view' title='chandroti-grampanchyat-view' />
			</li>
			<li class='num3 img'>
				<img src='data1/images/chanrohotigramactivity.jpg' alt='chanrohoti-gram-activity' title='chanrohoti-gram-activity' />
			</li>
		
		</ul>
		<a class="cs_lnk" href="http://cssslider.com">image slider</a>
		<div class='cs_description'>
			<label class='num0'>
				<span class="cs_title"><span class="cs_wrapper">chandrot-devlopment</span></span>
				
			</label>
			<label class='num1'>
				<span class="cs_title"><span class="cs_wrapper">chandroti-grampanchayat</span></span>
				
			</label>
			<label class='num2'>
				<span class="cs_title"><span class="cs_wrapper">chandroti-grampanchyat-view</span></span>
				
			</label>
			<label class='num3'>
				<span class="cs_title"><span class="cs_wrapper">chanrohoti-gram-activity</span></span>
				
			</label>
		</div>
		<div class='cs_play_pause'>
			<label class='cs_play' for='cs_play1'><span><i></i></span></label>
			<label class='cs_pause num0' for='cs_pause1_0'><span><i></i></span></label>
			<label class='cs_pause num1' for='cs_pause1_1'><span><i></i></span></label>
			<label class='cs_pause num2' for='cs_pause1_2'><span><i></i></span></label>
			<label class='cs_pause num3' for='cs_pause1_3'><span><i></i></span></label>
			
		</div>
		<div class='cs_arrowprev'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
		</div>
		<div class='cs_arrownext'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
			<label class='num3' for='cs_slide1_3'><span><i></i></span></label>
		</div>
		
		<div class='cs_bullets'>
			<label class='num0' for='cs_slide1_0'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/chandrotdevlopment.jpg' alt='chandrot-devlopment' title='chandrot-devlopment' /></span>
			</label>
			<label class='num1' for='cs_slide1_1'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/chandrotigrampanchayat.jpg' alt='chandroti-grampanchayat' title='chandroti-grampanchayat' /></span>
			</label>
			<label class='num2' for='cs_slide1_2'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/chandrotigrampanchyatview.jpg' alt='chandroti-grampanchyat-view' title='chandroti-grampanchyat-view' /></span>
			</label>
			<label class='num3' for='cs_slide1_3'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/chanrohotigramactivity.jpg' alt='chanrohoti-gram-activity' title='chanrohoti-gram-activity' /></span>
			</label>
		</div>
		
		</div>
