<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td> राकेश सिंह</td><td> प्रधान</td><td> -</td><td>+91-9837284191</td></tr>
					<tr><td>2</td><td>राजेश सिंह</td><td>  उपप्रधान</td><td> 7 </td><td>+91-7017677109</td></tr>
                    <tr><td>3</td><td>अनिता देवी</td><td> सदस्य</td><td>4</td><td>+91-9456112646</td></tr>
                    <tr><td>4</td><td>ज्ञान बाला</td><td> सदस्य</td><td> 5</td><td>+91-9897239945</td></tr>
                    <tr><td>5</td><td>बीना देवी</td><td> सदस्य</td><td> 1</td><td>+91-9557676086</td></tr>
                    <tr><td>6</td><td>पुष्पा देवी</td><td> सदस्य</td><td> 2</td><td>+91-9897203629</td></tr>
					<tr><td>7</td><td>पुष्पा</td><td> सदस्य</td><td> 3</td><td>+91-8394846357</td></tr>
					<tr><td>8</td><td>सुनीता</td><td> सदस्य</td><td> 7</td><td>+91-</td></tr>
					<tr><td>9</td><td>समीर</td><td> सदस्य</td><td> 8</td><td>+91-9411722850</td></tr>
					<tr><td>10</td><td>अमनदीप</td><td> सदस्य</td><td> 9</td><td>+91-8650953440</td></tr>
					
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
