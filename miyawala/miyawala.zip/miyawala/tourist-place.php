<?php include ('header.php'); ?>
      <div id="touristpage">
          <h2 align="center">   ग्राम पंचायत के मुख्य स्थल और पर्यटक स्थल</h2>
<p>उत्तराखंड, उत्तर भारत में स्थित एक बहुत ही खूबसूरत और शांत पर्यटन केंद्र है । इस जगह का शुमार देश की उन चुनिन्दा जगहों में है जो अपनी सुन्दरता के चलते दुनिया भर के पर्यटकों को अपनी ओर आकर्षित करती है।&nbsp; 'देवताओं की भूमि' के रूप में जाना जाने वाला उत्तराखंड अपने शांत वातावरण, मनमोहक दृश्यों और खूबसूरती के कारण पृथ्वी का स्वर्ग माना जाता है।</p>
<p>मियांवाला डोईवाला ब्लाक का मुख्य पर्यटन स्थल है , यहाँ दूर दूर से सैलानी आते हैं यहाँ काफी घूमने के स्थल हैं  ।</p>
<p> हमारी ग्राम पंचायत की मात्र 5 किमी की परिधि में लगभग सभी कुछ समाहित है | ग्राम वासी तथा  सेलानियो से नम्र निवेंदन है कि ग्राम पंचायत को स्वच्छ बनाये रखने में हमारा सहयोग करे | 
</p>
          <div id="tourist-box">
              <div id="touristpageleftbox"><img src="images/ranipokhri-grant-shivmandir.jpg" height="200" width="200" alt="ranipokhri-grant-shivmandir" title="ranipokhri-grant-shivmandir" /></div>
              <div id="touristpagerightbox"><h1>प्राचीन शिव मंदिर</h1> भक्तो की अपार श्रद्धा का केंद्र यह मंदिर अत्यंत प्राचीन हैं तथा इसमें लगभग सभी देवी-देवताओ की  प्रतिमाये स्थापित है | 
			  इसमें समय-सयम पर विभिन्न धार्मिक अनुष्ठानों  का आयोजन किया जाता है जैसे माता का जागरण ,भंजन कीर्तन  तथा जन्माष्टमी उत्सव  अत्यन्त हर्षोल्लास से मनाया जाता है | 
			 </div>
              <div class="cl"></div>
          </div>
          <div id="midabox"> <img src="images/swach-bharat-abhiyan1.jpg" alt="swach-bharat-abhiyan1" /></div>
          <div id="tourist-box1">
              <div id="touristpageleftbox1"> <h1>ग्रामदेवता </h1>यह बहुत विशाल है .. यहा काफी दूर दूर से लोग ग्रामदेवता के दर्शन करने आते हैं | इसमें समय-सयम पर विभिन्न धार्मिक अनुष्ठानों का आयोजन किया जाता है जैसे माता का जागरण ,भंजन कीर्तन तथा जन्माष्टमी उत्सव अत्यन्त हर्षोल्लास से मनाया जाता है|</div>
              <div id="touristpagerightbox1"><img src="images/ranipokhri-grant-gramdevta.jpg" height="200" width="200" alt="ranipokhri-grant-gramdevta" title="arya-samaj-mandir-dakpapthar" /> </div>
              <div class="cl"></div>
          </div>

          
         
      
       
 	   
          
      </div>
      
           <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
