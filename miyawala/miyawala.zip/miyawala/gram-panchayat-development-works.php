﻿<?php include ('header.php'); ?>
      <div id="touristpage">
          <h2 align="center">   ग्राम पंचायत में हुए विकास कार्यो की झलक</h2>

<table border="1">
<thead>
<th>क्रमांक</th><th>कार्य का नाम</th><th>योजना का नाम</th><th>वर्ष/ दिनांक</th><th>राशि</th><th>स्थिति</th>
</thead>
<tbody>
<tr><td>1</td><td>पंचायत घर-मरम्मत</td><td>राज्यवित्/13वित् आयोग</td><td>2015-16</td><td>6.5लाख</td><td>पूर्ण</td></tr>
<tr><td>1</td><td>विद्यालय-मरम्मत</td><td>राज्यवित्/13वित् आयोग</td><td>2015-16</td><td>10,000</td><td>पूर्ण</td></tr>
<tr><td>1</td><td>स्ट्रीट लाइट-मरम्मत</td><td>राज्यवित्/13वित् आयोग</td><td>2015-16</td><td>70000</td><td>पूर्ण</td></tr>
<tr><td>1</td><td>फर्नीचर</td><td>राज्यवित्/13वित् आयोग</td><td>14-15-16</td><td>150000</td><td>पूर्ण</td></tr>
</tbody>
</table>
 
  <p>नोट: प्रधान जी द्वारा किये गये जनहित  कार्यों का विवरण है, यह एक विकास वर्ष दिखलाता है | </p>        
          
       
 	   
          
      </div>
      
          <?php include 'footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
