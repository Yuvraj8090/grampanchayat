<div id="footer"><p> Design by - Vikash Sharma  || Hosting - www.universalwebsolutions.in</p>
    
	<h4 style="color:#F00;s">अपने बिज़नस, कॉलेज, स्कूल, कोचिंग सेन्टर, फर्म, की वेबसाइट बनवाने के लिए संपर्क करे  -  +91-9634039666 | +91- 94-1010-2425</h4>
</div>