<h1>ग्राम पंचायत की वेबसाइट के संदर्भ में </h1>
                <div style="border: 1px solid #0099FF;">
                   
                    <div id="historymantext"> <div id="historymanpic">
					<img src="images/miyawala-pradhan.jpg" height="150" width="140"></div>
					<p>इस  वेबसाइट  का निर्माण  2015 के  प्रधान ( <strong>श्रीमति पूजा नेगी w/O श्री विक्रान्त नेगी </strong>) जी द्वारा  किया गया है , 
					माननीय प्रधान जी को  अपनी ग्राम सभा को  पहली  बार इंटरनेट पर लाने का गौरव प्राप्त  हुआ  है , प्रधान जी  के  सहयोग से ही  इस वेबसाइट का निर्माण संभव  हुआ  है ।  
					अपनी  ग्राम  सभा को  पहली बार  इंटरनेट पर  लाने  के लिए  प्रधान  जी की सराहना करते  है । 
					<br /><br />
					
    </p>
                        <p style="text-align:right;">  
						<strong><a href="http://www.universalwebsolutions.in">Universal Web Solutions</a></strong>	
						 <br/>
					
                        </p> 
				</div>