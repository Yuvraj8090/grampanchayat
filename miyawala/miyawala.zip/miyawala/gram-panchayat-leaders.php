<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td>पूजा नेगी </td><td> प्रधान</td><td> -</td><td>+91-9997866309</td></tr>
					<tr><td>2</td><td>महेन्द्र सिंह बटोला</td><td>  उपप्रधान</td><td> 9</td><td>+91-9897867300</td></tr>
                    <tr><td>3</td><td>राजकुमार परमार </td><td> सदस्य</td><td>1</td><td>+91-9456514500</td></tr>
                    <tr><td>4</td><td>बीना पवार  </td><td> सदस्य</td><td> 2</td><td>+91-9897281408</td></tr>
                    <tr><td>5</td><td>भगवती नेगी</td><td> सदस्य</td><td> 3</td><td>+91-7895915281</td></tr>
                    <tr><td>6</td><td>शकुन्तला रावत</td><td> सदस्य</td><td> 4</td><td>0135285095</td></tr>
                    <tr><td>7</td><td>विरेन्द्र रावत</td><td> सदस्य</td><td> 5</td><td>+91-9410114046</td></tr>
					<tr><td>8</td><td>गीता बदोला</td><td> सदस्य</td><td> 6</td><td>+91-9675393254</td></tr>
					<tr><td>9</td><td>गणेश चन्द्र रमोला</td><td> सदस्य</td><td> 7</td><td>+91-9634763817</td></tr>
					<tr><td>10</td><td>आशिक अली</td><td> सदस्य</td><td> 8</td><td>+91-8449046292</td></tr>
					
					<tr><td>11</td><td>अल्पना शर्मा</td><td> सदस्य</td><td> 10</td><td>+91-9045921287</td></tr>
					<tr><td>12</td><td>अनिल बटोला</td><td> सदस्य</td><td> 11</td><td>+91-9897535844</td></tr>
					<tr><td>13</td><td>आशा वर्मा</td><td> सदस्य</td><td> 12</td><td>+91-8126534697</td></tr>
					<tr><td>14</td><td>हिमानी</td><td> सदस्य</td><td> 13</td><td>+91-9634234168</td></tr>
					<tr><td>15</td><td>के आर जोशी</td><td> ग्राम पंचायत विकास अधिकारी</td><td> -</td><td>+91-9997276058</td></tr>
					
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
