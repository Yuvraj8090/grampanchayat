<?php include ('header.php'); ?>

<div id="slider">
     <iframe src="https://www.google.com/maps/d/u/0/embed?mid=z3LuT1YP6tRw.k0ws88QOgULw" width="960" height="300"></iframe>	
      </div>   
    
        <div id="content">
            
            <div id="contentleft">
                <h1> मियांवाला ग्राम पंचायत </h1>
                <p>मियांवाला ग्राम पंचायत <br />
               ग्राम प्रधान <br/>
                   <strong> श्रीमती  पूजा देवी </strong><br />
               फ़ोन नंबर - +91- 9997866309<br />
               </p>
                
               <h1>मियांवाला ग्राम पंचायत पहुचने के साधन</h1>
<table border="1">
    <thead><th>क्रमांक</th><th>मुख्य तथ्य</th></thead>
                   
                <tbody>
                  
                    <tr><td>1</td><td>मियांवाला   से टेम्पो व बस सर्विस  12  बजे तक </td></tr>
                    <tr><td>2</td><td>देहरादून ISBT से हर 5 मिनिट में बस सर्विस मियांवाला  तक  8 बजे तक. </td></tr>
                    
                    
                </tbody>
                </table>
				<h1>मियांवाला ग्राम पंचायत मे निकटतम सुविधा से दुरी</h1>
				<table border="1">
    <thead><th>क्रमांक</th><th>विवरण</th><th>दुरी किमी</th><th>जगह</th></thead>
                   
                <tbody>
                   
                    <tr><td>1</td><td>राज्य की राजधानी</td><td>10 किमी</td><td>देहरादून </td></tr>
                    <tr><td>2</td><td>पेट्रोलियम शोध संस्थान</td><td>100मी</td><td>मियांवाला </td></tr>
                     <tr><td>3</td><td>गुलरघाटी</td><td>3 किमी</td><td>मियांवाला </td></tr>
					  <tr><td>4</td><td>लक्ष्मण सिद्ध मंदिर</td><td>1 किमी</td><td>मियांवाला </td></tr>
					   
							  <tr><td>12</td><td>रेलवे स्टेशन</td><td>500मी</td><td>हर्रावाला</td></tr>
							   <tr><td>13</td><td>हवाई अड्डा</td><td>20 किमी</td><td>जोलीग्रान्ट</td></tr>
							   
                </tbody>
                </table>

 
              <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads-jonsar.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer-jonsar.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
