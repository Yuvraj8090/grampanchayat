<link rel="stylesheet" href="engine1/style.css">
	<!--[if IE]><link rel="stylesheet" href="engine1/ie.css"><![endif]-->
	<!--[if lte IE 9]><script type="text/javascript" src="engine1/ie.js"></script><![endif]-->
	

	<div class='csslider1 autoplay '>
		<input name="cs_anchor1" id='cs_slide1_0' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_1' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_slide1_2' type="radio" class='cs_anchor slide' >
		<input name="cs_anchor1" id='cs_play1' type="radio" class='cs_anchor' checked>
		<input name="cs_anchor1" id='cs_pause1_0' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_1' type="radio" class='cs_anchor pause'>
		<input name="cs_anchor1" id='cs_pause1_2' type="radio" class='cs_anchor pause'>
		
		<ul>
			<div>
				<img src="data1/images/gajiawalagrampanchyat.jpg" style="width: 100%;">
			</div>
			<li class='num0 img'>
				<img src='data1/images/gajiawalagrampanchyat.jpg' alt='gajiawala-grampanchyat' title='gajiawala-grampanchyat' />
			</li>
			<li class='num1 img'>
				<img src='data1/images/gajiawalagrampanchyatview.jpg' alt='gajiawala-grampanchyat-view' title='gajiawala-grampanchyat-view' />
			</li>
			<li class='num2 img'>
				<img src='data1/images/gajiawalatemplehospital.jpg' alt='gajiawala-temple&-hospital' title='gajiawala-temple&-hospital' />
			</li>
		
		</ul>
		<a class="cs_lnk" href="http://cssslider.com">image slider</a>
		<div class='cs_description'>
			<label class='num0'>
				<span class="cs_title"><span class="cs_wrapper">gajiawala-grampanchyat</span></span>
				
			</label>
			<label class='num1'>
				<span class="cs_title"><span class="cs_wrapper">gajiawala-grampanchyat-view</span></span>
				
			</label>
			<label class='num2'>
				<span class="cs_title"><span class="cs_wrapper">gajiawala-temple&-hospital</span></span>
				
			</label>
		</div>
		<div class='cs_play_pause'>
			<label class='cs_play' for='cs_play1'><span><i></i></span></label>
			<label class='cs_pause num0' for='cs_pause1_0'><span><i></i></span></label>
			<label class='cs_pause num1' for='cs_pause1_1'><span><i></i></span></label>
			<label class='cs_pause num2' for='cs_pause1_2'><span><i></i></span></label>
			
		</div>
		<div class='cs_arrowprev'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
		</div>
		<div class='cs_arrownext'>
			<label class='num0' for='cs_slide1_0'><span><i></i></span></label>
			<label class='num1' for='cs_slide1_1'><span><i></i></span></label>
			<label class='num2' for='cs_slide1_2'><span><i></i></span></label>
		</div>
		
		<div class='cs_bullets'>
			<label class='num0' for='cs_slide1_0'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/gajiawalagrampanchyat.jpg' alt='gajiawala-grampanchyat' title='gajiawala-grampanchyat' /></span>
			</label>
			<label class='num1' for='cs_slide1_1'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/gajiawalagrampanchyatview.jpg' alt='gajiawala-grampanchyat-view' title='gajiawala-grampanchyat-view' /></span>
			</label>
			<label class='num2' for='cs_slide1_2'>
				<span class='cs_point'></span>
				<span class='cs_thumb'><img src='data1/tooltips/gajiawalatemplehospital.jpg' alt='gajiawala-temple&-hospital' title='gajiawala-temple&-hospital' /></span>
			</label>
		</div>
		
		</div>
