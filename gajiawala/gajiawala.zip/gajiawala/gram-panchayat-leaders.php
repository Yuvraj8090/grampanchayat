<?php include ('header.php'); ?>

<!--<div id="slider">
             Gmap
		
      </div>   -->
    
        <div id="content">
            
            <div id="contentleft">
                          <h2 align="center"> ग्राम पंचायत के प्रमुख जन प्रतिनिधि  </h2>

<!--                <table border="1" >
                    <thead><th>क्रमांक</th><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                <tbody>
                    <tr><td>1</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> प्रधान</td><td> 2</td><td>9634039666 , +91-9760343535</td></tr>
                    <tr><td>2</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> उपप्रधान</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>3</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>4</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>5</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                    <tr><td>6</td><td><img src="images/Badrinath.jpg" width="200" height="200" /><td>विकास शर्मा</td><td> सदस्य</td><td> 2</td><td>9634039666</td></tr>
                </tbody>
                </table>-->
                <table border="1" >
                    <thead><th>क्रमांक</th><th>नाम</th><th>पद</th><th>वार्ड</th><th>फ़ोन</th></thead>
                   
                <tbody>
                    <tr><td>1</td><td> राकेश शर्मा</td><td> प्रधान</td><td> -</td><td>+91-9358139480</td></tr>
					<tr><td>2</td><td>गणेश शर्मा</td><td>  उपप्रधान</td><td> 3 </td><td>+91-7017636988</td></tr>
                    <tr><td>3</td><td>कमल गुरुंग</td><td> सदस्य</td><td>1</td><td>+91-8979811263</td></tr>
                    <tr><td>4</td><td>रुपेश राना</td><td> सदस्य</td><td> 2</td><td>+91-9568310090</td></tr>
                    <tr><td>5</td><td>राशी कला गुरुंग</td><td> सदस्य</td><td> 4</td><td>+91-9997845318</td></tr>
                    <tr><td>6</td><td>तारा गुरुंग</td><td> सदस्य</td><td> 5</td><td>+91-9627005847</td></tr>
					<tr><td>7</td><td>मधु थापा</td><td> सदस्य</td><td> 6</td><td>+91-9761983246</td></tr>
					<tr><td>8</td><td>संजीव रावत</td><td> सदस्य</td><td> 7</td><td>+91-9927509739</td></tr>
					
                    
                </tbody>
                </table>
               <?php include'historyman.php'; ?>
                <div class="cl"></div>
                
                 </div>
            </div>
            
			 <div id="contentright">
				<?php include 'rightarea.php'; ?>
				<?php include('/home/grampanc/public_html/rightareaads.php');?>
          </div>
		     <div class="cl"></div>
        </div>
              
      <?php include '/home/grampanc/public_html/footer.php' ;?>
    </div> <!-- main container close -->
    </body>
</html>
